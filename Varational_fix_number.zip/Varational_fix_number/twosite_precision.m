function [mpsA, mpsB] = twosite_precision(mpsA, mpsB, mpoX, mpoY, precision)
%the modula of mps should not be changed
%mpo:%
%mpo1 = reshape(U, [2, 2, eta]); 
%mpo2 = reshape(V, [eta, 2, 2]); V=permute(V,[2 3 1]); 

    A=contracttensors(mpsA,3,3,mpoX,3,2);sizeA=size(A);
    B=contracttensors(mpsB,3,3,mpoY,3,2);sizeB=size(B);
    AB=contracttensors(A,4,[2 4],B,4,[1 4]);
    AB=permute(AB,[1 2 4 3]);AB=reshape(AB,[sizeA(1)*sizeA(3),sizeB(3)*sizeB(2)]);
    [u s v]=svd_precision(AB,precision);
    [dl dr]=size(u);
    u=reshape(u,[dl/sizeA(3),sizeA(3),dr]);
    u=permute(u,[1 3 2]);
    mpsA=u;
   [dl dr]=size(v);
   v=reshape(v,[dl,sizeB(3),dr/sizeB(3)]);v=permute(v,[1 3 2]);

    
    mpsB=contracttensors(s,2,2,v,3,1);
end