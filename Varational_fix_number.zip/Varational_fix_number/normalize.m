function mps0=normalize(mps0)
%��һ��

aa=overlap_1D(mps0,mps0);
mm=mps0{1,1};
mm=mm/sqrt(aa);
mps0{1,1}=mm;





