function SOC(L,n,D,alpha,t,t0,U,lamda,delta,two_site)


mpo_order=16;
precision = 1e-5;
M=8*(L-1)+2*L+L+8;
hset = cell(M, 2*L);
sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);
sp=(sx+i*sy)/2;sm=(sx-i*sy)/2;np=(eye(2)-sz)/2;
mu=0;

%bulk MPO
W=cell(1);
%j=1
M=zeros(1,10,4,4);
M(1,1,:,:)=eye(4);
M(1,2,:,:)=(-t-t0)*kron(sm,sz);
M(1,3,:,:)=(-t-t0)*kron(sp,sz);
M(1,4,:,:)=(-t+t0)*kron(eye(2),sm);
M(1,5,:,:)=(-t+t0)*kron(eye(2),sp);
M(1,6,:,:)=lamda*kron(sm,sz);
M(1,7,:,:)=lamda*kron(sp,sz);
M(1,8,:,:)=-lamda*kron(eye(2),sm);
M(1,9,:,:)=-lamda*kron(eye(2),sp);
M(1,10,:,:)=(delta-mu)*kron(np,eye(2))+(-delta-mu)*kron(eye(2),np)+U*kron(np,np);
W{1,1}=M;
%j=2:L-1
M=zeros(10,10,4,4);
M(1,1,:,:)=eye(4);
M(1,2,:,:)=(-t-t0)*kron(sm,sz);
M(1,3,:,:)=(-t-t0)*kron(sp,sz);
M(1,4,:,:)=(-t+t0)*kron(eye(2),sm);
M(1,5,:,:)=(-t+t0)*kron(eye(2),sp);
M(1,6,:,:)=lamda*kron(sm,sz);
M(1,7,:,:)=lamda*kron(sp,sz);
M(1,8,:,:)=-lamda*kron(eye(2),sm);
M(1,9,:,:)=-lamda*kron(eye(2),sp);
M(1,10,:,:)=(delta-mu)*kron(np,eye(2))+(-delta-mu)*kron(eye(2),np)+U*kron(np,np);
M(2,10,:,:)=kron(sp,eye(2));
M(3,10,:,:)=kron(sm,eye(2));
M(4,10,:,:)=kron(sz,sp);
M(5,10,:,:)=kron(sz,sm);
M(6,10,:,:)=kron(sz,sp);
M(7,10,:,:)=kron(sz,sm);
M(8,10,:,:)=kron(sp,eye(2));
M(9,10,:,:)=kron(sm,eye(2));
M(10,10,:,:)=eye(4);
for cj=2:L-1
W{1,cj}=M;    
end
%j=L
M=zeros(10,1,4,4);
M(1,1,:,:)=(delta-mu)*kron(np,eye(2))+(-delta-mu)*kron(eye(2),np)+U*kron(np,np);
M(2,1,:,:)=kron(sp,eye(2));
M(3,1,:,:)=kron(sm,eye(2));
M(4,1,:,:)=kron(sz,sp);
M(5,1,:,:)=kron(sz,sm);
M(6,1,:,:)=kron(sz,sp);
M(7,1,:,:)=kron(sz,sm);
M(8,1,:,:)=kron(sp,eye(2));
M(9,1,:,:)=kron(sm,eye(2));
M(10,1,:,:)=eye(4);
W{1,L}=M;


%boundary MPO
B=cell(1);
%j=1
M=zeros(1,8,4,4);
M(1,1,:,:)=(-t-t0)*kron(sm,sz);
M(1,2,:,:)=(-t-t0)*kron(sp,sz);
M(1,3,:,:)=(-t+t0)*kron(eye(2),sm);
M(1,4,:,:)=(-t+t0)*kron(eye(2),sp);
M(1,5,:,:)=lamda*kron(eye(2),sm);
M(1,6,:,:)=lamda*kron(eye(2),sp);
M(1,7,:,:)=-lamda*kron(sm,sz);
M(1,8,:,:)=-lamda*kron(sp,sz);
B{1,1}=M;
%j=2:L-1
M=zeros(8,8,4,4);
M(1,1,:,:)=kron(sz,sz);
M(2,2,:,:)=kron(sz,sz);
M(3,3,:,:)=kron(sz,sz);
M(4,4,:,:)=kron(sz,sz);
M(5,5,:,:)=kron(sz,sz);
M(6,6,:,:)=kron(sz,sz);
M(7,7,:,:)=kron(sz,sz);
M(8,8,:,:)=kron(sz,sz);
for cj=2:L-1
B{1,cj}=M;    
end
%j=L
M=zeros(8,1,4,4);
M(1,1,:,:)=kron(sp,eye(2));
M(2,1,:,:)=kron(sm,eye(2));
M(3,1,:,:)=kron(sz,sp);
M(4,1,:,:)=kron(sz,sm);
M(5,1,:,:)=kron(sp,eye(2));
M(6,1,:,:)=kron(sm,eye(2));
M(7,1,:,:)=kron(sz,sp);
M(8,1,:,:)=kron(sz,sm);
B{1,L}=M;


%adding MPO
MPO=adding_mpo(W,B,[1,1]);
%MPO_bulk=W;
%MPO_boundary=B;
%compress MPO

%MPO_c=compress_mpo(MPO,mpo_order);
MPO_c=MPO;%compress is slow when L=320

% ground state energy
fprintf('minimize energy\n');
if two_site==1
[E0,mps0,QL,DsL,QR,DsR]=minimizeE_two_site(MPO,n, D, 1e-3); 
mps=cell(1);
mps(1,1:L)=mps0;
mps(2,1:L)=QL;
mps(3,1:L)=QR;
mps(4,1:L)=DsL;
mps(5,1:L)=DsR;
[E0,mps0]=minimizeE_single_site(mps,MPO,n, D, precision);
clear mps;
elseif two_site==0
if isempty(alpha)
[E0, mps0]=minimizeE_SE(MPO,n, D, precision); 
else
[E0, mps0]=minimizeE_SE_alpha(MPO,n, D, precision,alpha); 
end
%[E0, mps0]=minimizeE_single_site(MPO,n, D, precision);
end
E0

mps0=left_norm(mps0);
E_error=overlap_1D(mpo_mps(MPO_c,mps0),mpo_mps(MPO_c,mps0))-overlap_1D(mps0,mpo_mps(MPO_c,mps0))^2
if two_site==1
filenm=['SOC_twosite_L_' num2str(L) '_n_' num2str(n) '_D_' num2str(D) '_U_' num2str(U) '_delta_' num2str(delta)];
elseif two_site==0
if isempty(alpha)
filenm=['SOC_L_' num2str(L) '_n_' num2str(n) '_D_' num2str(D) '_U_' num2str(U) '_delta_' num2str(delta)];
else
filenm=['SOC_L_alpha_' num2str(L) '_n_' num2str(n) '_D_' num2str(D) '_U_' num2str(U) '_delta_' num2str(delta)];
end
end
save([filenm]);


two_body=cell(2*L,2*L);
M=cell(1);for c1=1:2*L;M{1,c1}=eye(2);end
for ca=1:2*L
    for cb=1:2*L
        MM=M;
        for cj=min(ca,cb)+1:max(ca,cb)-1%the distance between ca and cb is at least 2
            MM{1,cj}=sz;
        end
        
        if ca<cb
            MM{1,ca}=sp;MM{1,cb}=sm;
        elseif ca==cb
            MM{1,ca}=np;
        elseif ca>cb
            MM{1,ca}=sm;MM{1,cb}=sp;
        end
       MMM=cell(1); 
        for cj=1:L
            MMM{1,cj}=reshape(kron(MM{1,2*cj-1},MM{1,2*cj}),[1,1,4,4]);
        end
        two_body{ca,cb}=MMM;
        
    end
end
M=two_body;
two_body=cell(1);
for ca=1:2*L
    for cb=1:2*L
        two_body{(ca+mod(ca,2))/2,(cb+mod(cb,2))/2,2-mod(ca,2),2-mod(cb,2)}=M{ca,cb};
    end
end


 
 %observable
for c1=1:L
    for c2=1:L
        for cs1=1:2
            for cs2=1:2
                ob(c1,c2,cs1,cs2)=overlap_1D(mps0,mpo_mps(two_body{c1,c2,cs1,cs2},mps0))/overlap_1D(mps0,mps0);
            end
        end
    end
end

%momentum occupation
correlation=zeros(L,2,2);
for c1=1:L
    kl(c1)=2*pi*c1/L;
    for ca=1:L
        for cb=1:L
            for cs1=1:2
                for cs2=1:2
                    correlation(c1,cs1,cs2)=correlation(c1,cs1,cs2)+1/L*exp(i*kl(c1)*(ca-cb))*ob(ca,cb,cs1,cs2);
                end
            end
        end
    end
end
 
n_total=sum(correlation(:,1,1))+sum(correlation(:,2,2))
 
E=E0+mu*n_total

sigmax=correlation(:,1,2)+correlation(:,2,1);
sigmay=i*correlation(:,1,2)-i*correlation(:,2,1);
sigmaz=correlation(:,1,1)-correlation(:,2,2);
 
sigmax;
sigmay;
sigmaz;

sigmay_norm=sigmay./sqrt((abs(sigmay.^2)+abs(sigmaz.^2)))
sigmaz_norm=sigmaz./sqrt((abs(sigmay.^2)+abs(sigmaz.^2)))

theta=mod(imag(log(i*sigmay_norm+sigmaz_norm)/2/pi),1)
%sin(theta*2*pi)
%cos(theta*2*pi)
clear mps0 two_body hset two_body hset MPO W B MPO_boundary MPO_bulk MPO_c MMM MM M;
save([filenm]);

