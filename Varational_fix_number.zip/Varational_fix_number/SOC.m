clc;clear;close all;
%o(1),o(2),o(3),o(4),...,o(l-1),O(l),o(l+1),...,o(2L)
%���������˳���Ǵ��ҵ��󣬼���2L��1.
L=3;%size
t=1;
t0=0.7;
U=4;
lamda=1.1;
delta=0.23;
mu=2;%chemical potential

D=30;
precision = 1e-5;
M=8*(L-1)+2*L+L+8;
hset = cell(M, 2*L);
sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);
sp=(sx+i*sy)/2;sm=(sx-i*sy)/2;np=(eye(2)-sz)/2;
for m=1:M,for j=1:2*L,hset{m,j}=id; end; end
for j=1:(L-1)
hset{8*(j-1)+1,2*j-1}=(-t-t0)*sm; hset{8*(j-1)+1,2*j}=sz; hset{8*(j-1)+1,2*j+1}=sp; 
hset{8*(j-1)+2,2*j-1}=(-t-t0)*sp; hset{8*(j-1)+2,2*j}=sz; hset{8*(j-1)+2,2*j+1}=sm; 
hset{8*(j-1)+3,2*j}=(-t+t0)*sm; hset{8*(j-1)+3,2*j+1}=sz; hset{8*(j-1)+3,2*j+2}=sp; 
hset{8*(j-1)+4,2*j}=(-t+t0)*sp; hset{8*(j-1)+4,2*j+1}=sz; hset{8*(j-1)+4,2*j+2}=sm; 
hset{8*(j-1)+5,2*j-1}=lamda*sm; hset{8*(j-1)+5,2*j}=sz; hset{8*(j-1)+5,2*j+1}=sz; hset{8*(j-1)+5,2*j+2}=sp; 
hset{8*(j-1)+6,2*j-1}=lamda*sp; hset{8*(j-1)+6,2*j}=sz; hset{8*(j-1)+6,2*j+1}=sz; hset{8*(j-1)+6,2*j+2}=sm; 
hset{8*(j-1)+7,2*j}=-lamda*sm; hset{8*(j-1)+7,2*j+1}=sp;  
hset{8*(j-1)+8,2*j}=-lamda*sp; hset{8*(j-1)+8,2*j+1}=sm; 
end
Np=cell(1);for m=1:2*L,for j=1:2*L,Np{m,j}=reshape(id,[1,1,2,2]); end; end
for j=1:L
hset{8*(L-1)+3*(j-1)+1,2*j-1}=(delta-mu)*np; Np{2*(j-1)+1,2*j-1}=reshape(np,[1,1,2,2]);
hset{8*(L-1)+3*(j-1)+2,2*j}=(-delta-mu)*np;  Np{2*(j-1)+2,2*j}=reshape(np,[1,1,2,2]);
hset{8*(L-1)+3*(j-1)+3,2*j-1}=U*np; hset{8*(L-1)+3*(j-1)+3,2*j}=np;
end

hset{8*(L-1)+3*(L-1)+3+1,1}=(-t-t0)*sm; for j=2:2*L-2; hset{8*(L-1)+3*(L-1)+3+1,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+1,2*L-1}=sp;
hset{8*(L-1)+3*(L-1)+3+2,1}=(-t-t0)*sp; for j=2:2*L-2; hset{8*(L-1)+3*(L-1)+3+2,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+2,2*L-1}=sm;
hset{8*(L-1)+3*(L-1)+3+3,2}=(-t+t0)*sm; for j=3:2*L-1; hset{8*(L-1)+3*(L-1)+3+3,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+3,2*L}=sp;
hset{8*(L-1)+3*(L-1)+3+4,2}=(-t+t0)*sp; for j=3:2*L-1; hset{8*(L-1)+3*(L-1)+3+4,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+4,2*L}=sm;
hset{8*(L-1)+3*(L-1)+3+5,2}=lamda*sm; for j=3:2*L-2; hset{8*(L-1)+3*(L-1)+3+5,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+5,2*L-1}=sp;
hset{8*(L-1)+3*(L-1)+3+6,2}=lamda*sp; for j=3:2*L-2; hset{8*(L-1)+3*(L-1)+3+6,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+6,2*L-1}=sm;
hset{8*(L-1)+3*(L-1)+3+7,1}=-lamda*sm; for j=2:2*L-1; hset{8*(L-1)+3*(L-1)+3+7,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+7,2*L}=sp;
hset{8*(L-1)+3*(L-1)+3+8,1}=-lamda*sp; for j=2:2*L-1; hset{8*(L-1)+3*(L-1)+3+8,j}=sz;end; hset{8*(L-1)+3*(L-1)+3+8,2*L}=sm;



% ground state energy
%randn('state', 0)%���ó�ʼ״̬
[E0, mps0] = minimizeE(hset, D, precision, []); 
E0;

H=cell(1);
for c1=1:size(hset,1)
    for c2=1:size(hset,2)
        H{c1,c2}=reshape(hset{c1,c2},[1,1,2,2]);
    end
end

ee=0;
for c1=1:size(H,1)
ee=ee+overlap_1D(mps0,mpo_mps(H(c1,:),mps0))/overlap_1D(mps0,mps0);
end


n_total=0;
for c1=1:size(Np,2)
    n_total=n_total+overlap_1D(mps0,mpo_mps(Np(c1,:),mps0))/overlap_1D(mps0,mps0);
end
 n_total  
 ee+mu*n_total
%  Hm=zeros(4^L,4^L);
%  for c1=1:size(hset,1)
%      M=hset{c1,1};
%      for c2=2:size(hset,2)
%          M=kron(M,hset{c1,c2});
%      end
%      Hm=Hm+M;
%  end
%  [ev,ee]=eig(Hm);
%  ee=diag(ee);
%  ee(1)
%  
%   Nm=zeros(4^L,4^L);
%  for c1=1:size(Np,1)
%      M=reshape(Np{c1,1},[2,2]);
%      for c2=2:size(Np,2)
%          M=kron(M,reshape(Np{c1,c2},[2,2]));
%      end
%      Nm=Nm+M;
%  end
%  ev(:,1)'*Nm*ev(:,1)
 
 
 
 
 
