function [u,s,v,Qn,ds]=svd_trun_twosite(A,D,qL,dsL,qR,dsR)
dl1=4;dr1=4;
Dl1=sum(dsL);Dr1=sum(dsR);

dstL=qn(qL,dsL);dstL=repmat(dstL',[1,dl1]);
dstl=[0,1,1,2];dstl=repmat(dstl,[Dl1,1]);
dstR=qn(qR,dsR);dstR=repmat(dstR',[1,dr1]);
dstr=[0,1,1,2];dstr=repmat(dstr,[Dr1,1]);

qqL=dstL-dstl;
qqR=dstR+dstr;
qqL=reshape(qqL,[1,Dl1*dl1]);
qqR=reshape(qqR,[1,Dr1*dr1]);

%check quantum number
% for c1=1:Dl1*dl1
%     for c2=1:Dr1*dr1
%         if abs(A(c1,c2))>0
%             [qqL(c1),qqR(c2)]
%         end
%     end
% end

[QQL,orderl]=sort(qqL);
QL=unique(QQL);DsL=[];
for c1=1:length(QL)
    DsL=[DsL,length(find(QL(c1)==QQL))];
end
%DsL

[QQR,orderr]=sort(qqR);
QR=unique(QQR);DsR=[];
for c1=1:length(QR)
    DsR=[DsR,length(find(QR(c1)==QQR))];
end
%DsR

AA=A(orderl,orderr);


l_order=eye(length(orderl));
l_order=l_order(orderl,:);

r_order=eye(length(orderr));
r_order=r_order(:,orderr);

%A=l_order'*AA*r_order';
%sum(sum(abs(A-AA)))

[u,s,v,Qn,ds]=svd_trun_qn(AA,D,QL,DsL,QR,DsR);


u=l_order'*u;
v=v*r_order';










