function [mps] = move_twosite(mps, l)
%�������ƶ�һ��
%����MB���AB��ʽ
A=mps{1,l};B=mps{1,l+1};
[Da1, Da2, d] = size(A); 
[Db1, Db2, d] = size(B); 


A = permute(A, [3, 1, 2]); A = reshape(A, [d * Da1, Da2]); 
B = permute(B, [1, 3, 2]); B = reshape(B, [Db1, d * Db2]);
AB=contracttensors(A,2,2,B,2,1);
[u,s,v] = svd2(AB); D = size(s, 1);
u = reshape(u, [d, Da1, D]); u = permute(u, [2, 3, 1]);
v=contracttensors(s,2,2,v,2,1);
v=reshape(v,[D,d,Db2]);v=permute(v,[1 3 2]);
mps{1,l}=u;mps{1,l+1}=v;


end