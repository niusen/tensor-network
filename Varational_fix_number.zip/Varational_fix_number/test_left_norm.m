clc;clear;
randn('state', 0);%
D1=6;D2=5;d=4;
a=randn(D1,D2,d);%D1:0 1 2, d:0 1, D2:0 1 2 3
M=zeros(D1,D2,d);
qR=[1,2,3];
dsR=[2,1,2];

qL=[2,3,4,7];
dsL=[1,2,2,1];

nd=[0 1 1 2];

for cl=1:length(qL)
    for cr=1:length(qR)
        for cd=1:d
            if qL(cl)==qR(cr)+nd(cd)
                M(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd)=a(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd);
            end
        end
    end
end

M=reshape(M,[D1,D2*d]);%M=[M(:,:,1),M(:,:,2),M(:,:,3),M(:,:,4)];
qRd=[qR+nd(1),qR+nd(2),qR+nd(3),qR+nd(4)];%the grouped indice
dsRd=[dsR,dsR,dsR,dsR];

[u s v]=svd2(M);

qRd_new=unique(qRd);
r_order=[];
for c1=1:length(qRd_new)
    for c2=1:length(qRd)
        if qRd_new(c1)==qRd(c2)
            r_order=[r_order,sum(dsRd(1:c2-1))+1:sum(dsRd(1:c2))];
        end
    end
    
end

for c1=1:length(qRd_new)
    dsRd_new(c1)=sum(dsRd(find(qRd==qRd_new(c1))));
end


MM=M(:,r_order);
R_order=eye(length(r_order));
R_order=R_order(:,r_order);

[u,s,v,qL_newnew,dsL_newnew,qR_newnew,dsR_newnew]=svd_qn(MM,qL,dsL,qRd_new,dsRd_new);
u*s*v-MM

v=v*R_order';

u=u*s;
v=reshape(v,[size(v,1),D2,d]);

 