%Creation of a random MPS with d=4:
function mps_total=createrandommps_qn(L, D, n)
randn('state', 0);%���ó�ʼ״̬
d=4;
mps = cell(1, L);
mps{1} = randn(1, D, d)/sqrt(D);
mps{L} = randn(D, 1, d)/sqrt(D);
for i=2:(L-1)
mps{i} = randn(D, D, d)/sqrt(D);
end

mps=right_norm(mps);mps=left_norm(mps);


QL=cell(1,L);%quantum number of left bond
QR=cell(1,L);%quantum number of right bond
DsL=cell(1,L);%quantum number distribution of left bond
DsR=cell(1,L);%quantum number distribution of right bond

nd=[0 1 1 2];
%project particle number from right to left
qR=0;
c1=L;
[Dl,Dr,d]=size(mps{1,c1});
dsR=1;
qL=[qR+nd(1),qR+nd(2),qR+nd(3),qR+nd(4)];%0, up, down, douple
qL=unique(qL);
for cn=1:length(qL)
    if qL(cn)>n
        qL(cn:length(qL))=[];%project out particle numbers larger than n
        break;
    end
end
n_average=round(n*(L-c1+1)/L);
weight=(qL-n_average).^2;
[new_weight,new_order]=sort(weight);
n_select=4;%only pick out two quantum numbers near the average particle number
for cq=1:min(n_select,length(weight))
    new_qL(cq)=qL(new_order(cq));
end
qL=sort(new_qL);%the selected qL quantum numbers
dsL=ones(1,length(qL))*floor(Dl/length(qL));
dsL(1)=dsL(1)+Dl-sum(dsL);%distribute the residue Dl
M=zeros(Dl,Dr,d);MM=mps{1,c1};

for cl=1:length(qL)
    for cr=1:length(qR)
        for cd=1:d
            if qL(cl)==qR(cr)+nd(cd)
                M(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd)=MM(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd);
            end
        end
    end
end
QL{1,c1}=qL; 
QR{1,c1}=qR; 
DsL{1,c1}=dsL; 
DsR{1,c1}=dsR; 
mps{1,c1}=M;
      
    
for c1=L-1:-1:2
qR=QL{1,c1+1};
dsR=DsL{1,c1+1};
[Dl,Dr,d]=size(mps{1,c1});
qL=[qR+nd(1),qR+nd(2),qR+nd(3),qR+nd(4)];%0, up, down, douple
qL=unique(qL);
for cn=1:length(qL)
    if qL(cn)>n
        qL(cn:length(qL))=[];%project out particle numbers larger than n
        break;
    end
end
n_average=round(n*(L-c1+1)/L);
weight=(qL-n_average).^2;
[new_weight,new_order]=sort(weight);
n_select=4;%only pick out two quantum numbers near the average particle number
for cq=1:min(n_select,length(weight))
    new_qL(cq)=qL(new_order(cq));
end
qL=sort(new_qL);%the selected qL quantum numbers
dsL=ones(1,length(qL))*floor(Dl/length(qL));
dsL(1)=dsL(1)+Dl-sum(dsL);%distribute the residue Dl
M=zeros(Dl,Dr,d);MM=mps{1,c1};
for cl=1:length(qL)
    for cr=1:length(qR)
        for cd=1:d
            if qL(cl)==qR(cr)+nd(cd)
                M(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd)=MM(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd);
            end
        end
    end
end
QL{1,c1}=qL; 
QR{1,c1}=qR; 
DsL{1,c1}=dsL; 
DsR{1,c1}=dsR; 
mps{1,c1}=M;
    
end


c1=1;
qR=QL{1,c1+1};
dsR=DsL{1,c1+1};
[Dl,Dr,d]=size(mps{1,c1});
qL=n;
dsL=1;
M=zeros(Dl,Dr,d);MM=mps{1,c1};
for cl=1:length(qL)
    for cr=1:length(qR)
        for cd=1:d
            if qL(cl)==qR(cr)+nd(cd)
                M(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd)=MM(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd);
            end
        end
    end
end


QL{1,c1}=qL; 
QR{1,c1}=qR; 
DsL{1,c1}=dsL; 
DsR{1,c1}=dsR; 
mps{1,c1}=M;




mps_total(1,1:L)=mps;
mps_total(2,1:L)=QL;
mps_total(3,1:L)=QR;
mps_total(4,1:L)=DsL;
mps_total(5,1:L)=DsR;
