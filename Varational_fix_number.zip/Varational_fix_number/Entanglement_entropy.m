function [bond,entropy_1,entropy_0d5]=Entanglement_entropy(mps)
N=size(mps,2);
bond=zeros(1,N-1);
entropy_1=zeros(1,N-1);
entropy_0d5=zeros(1,N-1);
for c1=1:N-1
    bond(c1)=size(mps{1,c1},2);
end

%��������
for i = N:-1:2
A=mps{i};    
[D1, D2, d] = size(A); 
A = permute(A, [1, 3, 2]); A = reshape(A, [D1, d * D2]); 
[U, S, B] = svd2(A); DB = size(S, 1);S=S/max(max(abs(S)));
B = reshape(B, [DB, d, D2]); B = permute(B, [1, 3, 2]); 
U=U*S;    
mps{i}=B;    
mps{i-1} = contracttensors(mps{i-1}, 3, 2, U, 2, 1); 
mps{i-1} = permute(mps{i-1}, [1, 3, 2]);
end

%��������
for i = 1:N-1
A=mps{i};  
[D1, D2, d] = size(A); 
A = permute(A, [3, 1, 2]); A = reshape(A, [d * D1, D2]); 
[B, S, U] = svd2(A); DB = size(S, 1);S=S/max(max(abs(S)));
B = reshape(B, [d, D1, DB]); B = permute(B, [2, 3, 1]);
U=S*U;
%%%%rho
rho=U*U';
rho=eig(rho);rho=rho/sum(rho);
entropy_1(i)=-sum(rho.*log(rho)/log(2));
entropy_0d5(i)=log(sum(rho.^(0.5)))/(1-0.5)/log(2);
%%%%
mps{i}=B;  
mps{i+1} = contracttensors(U, 2, 2, mps{i+1}, 3, 1); 
end




