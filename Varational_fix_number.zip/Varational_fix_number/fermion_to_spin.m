function mpo=fermion_to_spin(MPO)
[M,N]=size(MPO);
mpo=cell(1);
for cm=1:M
for cn=1:N
Ma=MPO{cm,cn};
[Dl,Dr,d1,d2]=size(Ma);
Ma=reshape(Ma,[Dl,Dr,2,2,2,2]);
Ma=permute(Ma,[1,2,4,6,3,5]);
Ma=reshape(Ma,[Dl,Dr,4,4]);%Dl,Dr,dl,dr
Ma=permute(Ma,[1,3,2,4]);%Dl,dl,Dr,dr
Ma=reshape(Ma,[Dl*4,Dr*4]);
[U S V]=svd(Ma);
V=S*V';
D=size(U,2);
U=reshape(U,[Dl,4,D]);U=reshape(U,[Dl,2,2,D]);U=permute(U,[1,4,2,3]);
V=reshape(V,[D,Dr,4]);V=reshape(V,[D,Dr,2,2]);
mpo{cm,2*cn-1}=U;mpo{cm,2*cn}=V;
end
end