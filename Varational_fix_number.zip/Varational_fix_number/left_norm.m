function mps=left_norm(mps)
%from right to left
N=size(mps,2);
for c1=N:-1:2
M=mps{1,c1};[D1,D2,d]=size(M); 
M=permute(M,[1,3,2]);M=reshape(M,[D1,d*D2]); 
[U,S,B]=svd2(M);DB=size(S, 1);
B=reshape(B,[DB,d,D2]); B=permute(B,[1,3,2]); 
mps{1,c1}=B;
US=U*S;
mps{1,c1-1}=contracttensors(mps{1,c1-1},3,2,US,2,1); 
mps{1,c1-1}=permute(mps{1,c1-1},[1,3,2]);
end
%normalize
A=mps{1,1};
[D1,D2,d]=size(A);
A=reshape(A,[D2*d,1]);
ov=A'*A;
mps{1,1}=mps{1,1}/sqrt(ov);
