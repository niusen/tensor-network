function [E,mps,QL,DsL,QR,DsR] = minimizeE_two_site(hset,n, D, precision)


[M, N] = size(hset);
mps0 = createrandommps_qn(N, D, n);
d=4;
mps0 = left_norm_qn(mps0);
mps=mps0(1,:);
QL=mps0(2,:);
QR=mps0(3,:);
DsL=mps0(4,:);
DsR=mps0(5,:);
% storage-initialization

Hstorage = initHstorage_mpo(mps, hset, d);%������������,��ֻ��ʼ������2��site����һ��site����Ҫ�㣬��Ϊ����sweep��ʱ��ӵ�һ��site��ʼ�����⣬������һ��sweep�Ǵ������ң�Hleft = Hstorage(:, 1)=1��������Ҫ��;
%ע�⣬Hstorage_i��ָ����ͣ����site i-1 �� site i֮���ָ��D_{i-1}, D_{i-1}'


% optimization sweeps 
%two_site_sweep=0;
%while 1
for two_site_sweep=1:8    
Evalues = [];
% ********* cycle 1: j ! j ? 1 (from 1 to N   1)********* 
for j=1:N-2%���µ���N-2��site
%j
% optimization,��������

Hleft = Hstorage(:, j);%Hleft��Ȼ��cell,��j=1��ʼ
Hright = Hstorage(:, j + 2);
hsetj = hset(:, j:j+1);


[u,s,v,Qn,ds,E] = minimizeE_twosite(hsetj, Hleft, Hright,QL{1,j},DsL{1,j},QR{1,j+1},DsR{1,j+1},n,size(mps{1,j},2)); 
%minimizeE_twosite0(hsetj, Hleft, Hright,QL{1,j},DsL{1,j},QR{1,j+1},DsR{1,j+1},n,size(mps{1,j},2)); 
%load H1;load H2;sum(sum(abs(H1-H2)))
%load A1;load A2;1-A1'*A2
%load posit1;load posit2;sum(sum(abs(posit1-posit2)))
%E
v=s*v;
u=reshape(u,[size(mps{1,j},1),4,size(mps{1,j},2)]);mps{1,j}=permute(u,[1,3,2]);
mps{1,j+1}=reshape(v,[size(mps{1,j+1},1),size(mps{1,j+1},2),4]);
QL{1,j+1}=Qn;
DsL{1,j+1}=ds;
QR{1,j}=Qn;
DsR{1,j}=ds;

Evalues = [Evalues, E];
% storage-update
for m=1:M
h =hset{m, j};
Hstorage{m, j + 1} = updateCleft(Hleft{m}, mps{1,j}, h, mps{1,j}); %�������Ҹ���
end

end

% ****************** cycle 2: j = j+  1 (from N to 2) ****************** 
for j = N:(-1):3
%j
% minimization
Hleft = Hstorage(:, j-1);
Hright = Hstorage(:, j + 1);
hsetj = hset(:, j-1:j);



[u,s,v,Qn,ds,E] = minimizeE_twosite(hsetj, Hleft, Hright,QL{1,j-1},DsL{1,j-1},QR{1,j},DsR{1,j},n,size(mps{1,j},1)); 
%E
%minimizeE_twosite0(hsetj, Hleft, Hright,QL{1,j-1},DsL{1,j-1},QR{1,j},DsR{1,j},n,size(mps{1,j},1)); 
%load H1;load H2;sum(sum(abs(H1-H2)))
%load A1;load A2;1-A1'*A2
%load posit1;load posit2;sum(sum(abs(posit1-posit2)))
%E
u=u*s;
u=reshape(u,[size(mps{1,j-1},1),4,size(mps{1,j-1},2)]);mps{1,j-1}=permute(u,[1,3,2]);
mps{1,j}=reshape(v,[size(mps{1,j},1),size(mps{1,j},2),4]);
QL{1,j}=Qn;
DsL{1,j}=ds;
QR{1,j-1}=Qn;
DsR{1,j-1}=ds;

Evalues = [Evalues, E];
% storage-update 
for m=1:M
h = hset{m, j};
Hstorage{m, j} = updateCright(Hright{m}, mps{1,j}, h, mps{1,j});
end

end

%two_site_sweep=two_site_sweep+1;
fprintf('two_site_sweep = %d, std = %.2e\n',two_site_sweep,(std(Evalues)/abs(mean(Evalues))));



if (std(Evalues)/abs(mean(Evalues)) < precision) 

break;
end



end

end





% ******************** one-site optimization *********************** 
function [u,s,v,Qn,ds,E] = minimizeE_twosite(hsetj, Hleft, Hright,qL,dsL,qR,dsR,n,D)
% calculation of Heff 

Dl1=sum(dsL);Dr1=sum(dsR);dl1=4;dr1=4;
dstL=qn(qL,dsL);dstLp=n-dstL;dstLp=repmat(dstLp',[1,dl1,Dr1,dr1]);n_Lp=repmat([1:Dl1]',[1,dl1,Dr1,dr1]);
dstR=qn(qR,dsR);dstR=repmat(dstR,[Dl1,1,dl1,dr1]);dstR=permute(dstR,[1,3,2,4]);n_R=repmat([1:Dr1],[Dl1,1,dl1,dr1]);n_R=permute(n_R,[1,3,2,4]);
dstdl=[0,1,1,2];dstl=repmat(dstdl,[Dl1,1,Dr1,dr1]);n_dl=repmat([1:dl1],[Dl1,1,Dr1,dr1]);
dstdr=[0,1,1,2];dstr=repmat(dstdr,[Dl1,1,dl1,Dr1]);dstr=permute(dstr,[1,3,4,2]);n_dr=repmat([1:dr1],[Dl1,1,dl1,Dr1]);n_dr=permute(n_dr,[1,3,4,2]);
basis_qn=dstLp+dstR+dstl+dstr;
basis_qn=reshape(basis_qn,[1,Dl1*dl1*Dr1*dr1]);
posit=find(basis_qn==n*ones(1,Dl1*dl1*Dr1*dr1));

n_Lp=reshape(n_Lp,[Dl1,dl1,Dr1,dr1]);
n_R=reshape(n_R,[Dl1,dl1,Dr1,dr1]);
n_dl=reshape(n_dl,[Dl1,dl1,Dr1,dr1]);
n_dr=reshape(n_dr,[Dl1,dl1,Dr1,dr1]);


dstLp=reshape(dstLp,[Dl1,dl1,Dr1,dr1]);
dstR=reshape(dstR,[Dl1,dl1,Dr1,dr1]);
dstl=reshape(dstl,[Dl1,dl1,Dr1,dr1]);
dstr=reshape(dstr,[Dl1,dl1,Dr1,dr1]);

for c1=1:length(posit)
[dstLp(posit(c1)),dstl(posit(c1)),dstR(posit(c1)),dstr(posit(c1))];
end

%[dstLp(50),dstl(50),dstR(50),dstr(50)]
%[dstLp(51),dstl(51),dstR(51),dstr(51)]
%[dstLp(54),dstl(54),dstR(54),dstr(54)]
%[dstLp(55),dstl(55),dstR(55),dstr(55)]

a=[1:Dl1*dl1*Dr1*dr1];a=reshape(a,[Dl1,dl1,Dr1,dr1]);%b=a(1:1,2:2,13:16,1);b=reshape(b,[1,prod(size(b))]);
bb=[];


qdl=[0,1,1,2];dsdl=[1,1,1,1];
qdr=[0,1,1,2];dsdr=[1,1,1,1];
step=1;
for c4=1:length(qdr) 
for c3=1:length(qR)
for c2=1:length(qdl)
for c1=1:length(qL)


   




            if n-qL(c1)+qR(c3)+qdl(c2)+qdr(c4)==n
               keep_1(step,1)=sum(dsL(1:c1-1))+1;keep_2(step,1)=sum(dsL(1:c1)); 
               keep_1(step,2)=sum(dsdl(1:c2-1))+1;keep_2(step,2)=sum(dsdl(1:c2));
               keep_1(step,3)=sum(dsR(1:c3-1))+1;keep_2(step,3)=sum(dsR(1:c3)); 
               keep_1(step,4)=sum(dsdr(1:c4-1))+1;keep_2(step,4)=sum(dsdr(1:c4));
               keep_q(step,1:4)=[qL(c1),qdl(c2),qR(c3),qdr(c4)];
               b=a(sum(dsL(1:c1-1))+1:sum(dsL(1:c1)),sum(dsdl(1:c2-1))+1:sum(dsdl(1:c2)),sum(dsR(1:c3-1))+1:sum(dsR(1:c3)),sum(dsdr(1:c4-1))+1:sum(dsdr(1:c4)));
               [a1 a2 a3,a4]=size(b);b=reshape(b,[1,a1*a2*a3*a4]);bb=[bb,b];
               step=step+1;
            end
end
end
end
end

% keep_1
% keep_2
% keep_q
% bb
H=zeros(length(posit),length(posit));
Hl=Hleft{1};
Hsetl=hsetj{1,1};
Hsetr=hsetj{1,2};
Hr=Hright{1};
for c1=1:size(keep_q,1)
    leng_keep(c1)=prod((keep_2(c1,:)-keep_1(c1,:))+1);
end

%tic
for c1=1:size(keep_q,1)
    for c2=1:size(keep_q,1)
        
        Heffm=contracttensors(Hl(keep_1(c1,1):keep_2(c1,1),:,keep_1(c2,1):keep_2(c2,1)),3,2,Hsetl(:,:,keep_1(c1,2):keep_2(c1,2),keep_1(c2,2):keep_2(c2,2)),4,1);%Dl1,Dl3,w,dl1,dl3
        Heffm=contracttensors(Heffm,5,3,Hsetr(:,:,keep_1(c1,4):keep_2(c1,4),keep_1(c2,4):keep_2(c2,4)),4,1);%Dl1,Dl3,dla,dlb,w,dr1,dr3
        Heffm=contracttensors(Heffm,7,5,Hr(keep_1(c1,3):keep_2(c1,3),:,keep_1(c2,3):keep_2(c2,3)),3,2);%Dl1,Dl3,dl1,dl3,dr1,dr3,Dr1,Dr3 
        Heffm=permute(Heffm,[1,3,7,5,2,4,8,6]);
        [Dl1p,dl1p,Dr1p,dr1p,Dl3p,dl3p,Dr3p,dr3p]=size(Heffm);
        Heffm=reshape(Heffm,[Dl1p*dl1p*Dr1p*dr1p,Dl3p*dl3p*Dr3p*dr3p]); 
        H(sum(leng_keep(1:c1-1))+1:sum(leng_keep(1:c1)),sum(leng_keep(1:c2-1))+1:sum(leng_keep(1:c2)))=Heffm;

    end
end

[bb_new,order]=sort(bb);
H=H(order,order);



%size(H)

% optimization
options.disp = 0;
%Heff;
%sum(sum(abs(H-H')))
H=(H+H')/2;
[A, E] = eigs(H, 1, 'sr', options);

%A1=A;
%save A1 A1;
%H1=H;save H1 H1; 
AA=zeros(1,Dl1*dl1*Dr1*dr1);
for c1=1:length(posit)
    AA(posit(c1))=A(c1);
end
A=reshape(AA, [Dl1*dl1,Dr1*dr1]);


%posit1=posit;
%save posit1 posit1;

[u,s,v,Qn,ds]=svd_trun_twosite(A,D,qL,dsL,qR,dsR);
%E



end



% %******************** one-site optimization *********************** 
% function [u,s,v,Qn,ds,E] = minimizeE_twosite0(hsetj, Hleft, Hright,qL,dsL,qR,dsR,n,D)
% % calculation of Heff 
% Heffm=contracttensors(Hleft{1},3,2,hsetj{1,1},4,1);%Dl1,Dl3,w,dl1,dl3
% Heffm=contracttensors(Heffm,5,3,hsetj{1,2},4,1);%Dl1,Dl3,dla,dlb,w,dr1,dr3
% Heffm=contracttensors(Heffm,7,5,Hright{1},3,2);%Dl1,Dl3,dl1,dl3,dr1,dr3,Dr1,Dr3 
% Heffm=permute(Heffm,[1,3,7,5,2,4,8,6]);
% [Dl1,dl1,Dr1,dr1,Dl3,dl3,Dr3,dr3]=size(Heffm);
% Heff=reshape(Heffm,[Dl1*dl1*Dr1*dr1,Dl3*dl3*Dr3*dr3]);    
% 
% 
% 
% dstL=qn(qL,dsL);dstLp=n-dstL;dstLp=repmat(dstLp',[1,dl1,Dr1,dr1]);
% dstR=qn(qR,dsR);dstR=repmat(dstR,[Dl1,1,dl1,dr1]);dstR=permute(dstR,[1,3,2,4]);
% dstdl=[0,1,1,2];dstl=repmat(dstdl,[Dl1,1,Dr1,dr1]);
% dstdr=[0,1,1,2];dstr=repmat(dstdr,[Dl1,1,dl1,Dr1]);dstr=permute(dstr,[1,3,4,2]);
% basis_qn=dstLp+dstR+dstl+dstr;
% basis_qn=reshape(basis_qn,[1,Dl1*dl1*Dr1*dr1]);
% posit=find(basis_qn==n*ones(1,Dl1*dl1*Dr1*dr1));
% 
% %posit
% 
% 
% H=zeros(length(posit),length(posit));
% for c1=1:length(posit)
%     for c2=1:length(posit)
%         H(c1,c2)=Heff(posit(c1),posit(c2));
%     end
% end
% 
% %size(H)
% 
% % optimization
% options.disp = 0;
% %Heff;
% %sum(sum(abs(H-H')))
% H=(H+H')/2;
% [A, E] = eigs(H, 1, 'sr', options); 
% 
% %A2=A;
% %save A2 A2;
% %H2=H;save H2 H2;
% AA=zeros(1,Dl1*dl1*Dr1*dr1);
% for c1=1:length(posit)
%     AA(posit(c1))=A(c1);
% end
% A=reshape(AA, [Dl1*dl1,Dr1*dr1]);
% 
% 
% %posit2=posit;
% %save posit2 posit2;
% 
% [u,s,v,Qn,ds]=svd_trun_twosite(A,D,qL,dsL,qR,dsR);
% %E
% 
% 
% 
% end





