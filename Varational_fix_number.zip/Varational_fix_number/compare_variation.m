clc;clear;
load MPO_c;
hset=MPO_c;
load matlab.mat;
D=10;precision=1e-5;
n=4;
tic
[E, mps1] = minimizeE_single_site(hset,n, D, precision);
mps11=mps1(1,:);
toc
E
tic
[E, mps2] = minimizeE_mpo(hset, D, precision,[],4);
toc
E


%observable
for c1=1:L
    for c2=1:L
        for cs1=1:2
            for cs2=1:2
                ob(c1,c2,cs1,cs2)=overlap_1D(mps2,mpo_mps(two_body{c1,c2,cs1,cs2},mps2))/overlap_1D(mps2,mps2);
            end
        end
    end
end

%momentum occupation
correlation=zeros(L,2,2);
for c1=1:L
    kl(c1)=2*pi*c1/L;
    for ca=1:L
        for cb=1:L
            for cs1=1:2
                for cs2=1:2
                    correlation(c1,cs1,cs2)=correlation(c1,cs1,cs2)+1/L*exp(i*kl(c1)*(ca-cb))*ob(ca,cb,cs1,cs2);
                end
            end
        end
    end
end
 
n_total=sum(correlation(:,1,1))+sum(correlation(:,2,2))