clc;clear;
randn('state', 0);%
L=100;D=200;n=57;
mps0=createrandommps_qn(L, D, n);
%mps0=left_norm_qn(mps0);
mps00=mps0(1,:);
mps1=right_norm_position_qn(mps0,1,99);
mps11=mps1(1,:);

mps2=left_norm_position_qn(mps0,100,2);
mps22=mps2(1,:);

overlap_1D(mps11,mps00)/sqrt(overlap_1D(mps00,mps00)*overlap_1D(mps11,mps11))
overlap_1D(mps22,mps00)/sqrt(overlap_1D(mps00,mps00)*overlap_1D(mps22,mps2))


a1=mps11{1,1};
size(a1);
mps0{2,1}
mps0{3,1}
mps0{4,1}
mps0{5,1}

mps1{2,1}
mps1{3,1}
mps1{4,1}
mps1{5,1}

mps0{2,1}
mps0{3,1}
mps0{4,1}
mps0{5,1}

mps2{2,1}
mps2{3,1}
mps2{4,1}
mps2{5,1}

