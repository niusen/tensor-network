function su=test_block(a,QL,DsL,QR,DsR)
qL=qn(QL,DsL);
qR=qn(QR,DsR);
dd=[0,1,1,2];
su=0;
for c1=1:size(a,1)
    for c2=1:size(a,2)
        for c3=1:size(a,3)
            if qL(c1)~=(qR(c2)+dd(c3))
                if abs(a(c1,c2,c3)>0)
                    
                    su=su+abs(a(c1,c2,c3));
                end
            end
            
        end
    end
end


