function new_mpo=compress_mpo(HamiltonianO,order)
DD=2;
precision=10^-6;
N=length(HamiltonianO);
mpo_id=cell(1,N);
d=size(HamiltonianO{1,2},3);
for c1=1:N
    mpo_id{1,c1}=reshape(eye(d^2),[1,1,d^2,d^2]);
end
%mpo ��ʽ: D1,D2,d1,d2
MPS=cell(1,N);

for c1=1:N
        mt=HamiltonianO{1,c1};
        [D1,D2,d1,d2]=size(mt);
        mt=reshape(mt,[D1,D2,d1*d2]);
        MPS{1,c1}=mt;
end
    
tole=0;
step=1; 
while tole<1-10^(-order)
[reduced_mpo K] = reduceD(MPS, mpo_id,DD+step-1, precision);
tole=overlap_1D(MPS,reduced_mpo)/sqrt(overlap_1D(reduced_mpo,reduced_mpo)*overlap_1D(MPS,MPS));
step=step+1;
end



new_mpo=cell(1,N);
for c1=1:N
        mt=reduced_mpo{1,c1};
        [D1,D2,d1_d2]=size(mt);
        mt=reshape(mt,[D1,D2,d1,d2]);
        new_mpo{1,c1}=mt;
end

