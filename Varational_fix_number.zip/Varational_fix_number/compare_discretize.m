clc;clear;close all;

N=39;
discretize_type=1;%type 1: constant discretize; type2: equal area discretize
nstep=15;%��������
no_w=100001;
U=4;
hopping=1;
D0=50;
precision=10^-7;
symmetric=0;
t_max=15;
dt=0.05;
omega_max=5;

wn=linspace(-4,4,no_w);
for c1=1:length(wn)
    if abs(wn(c1))<=2
    G(c1)=sqrt(4-(wn(c1)).^2)/2/pi;
    else 
        G(c1)=0;
    end
   
end

%discretize_type=1;
parameters=Discretize_bath_constant(N,wn,G,U,hopping);
Semielliptic_ground_Variation_MPO(N,parameters,D0)
wn=linspace(-omega_max,omega_max,no_w);
[G_t1,TT1]=G_fork_fun(N,D0,precision,symmetric,t_max,dt);


%discretize_type=2;
parameters=Discretize_bath_area(N,wn,G,U,hopping);
Semielliptic_ground_Variation_MPO(N,parameters,D0)
wn=linspace(-omega_max,omega_max,no_w);
[G_t2,TT2]=G_fork_fun(N,D0,precision,symmetric,t_max,dt);


save compare_discretize;
