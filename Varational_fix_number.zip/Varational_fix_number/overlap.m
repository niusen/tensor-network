%Expectation value of the MPS mps with respect to the operator defined in hset:
function [e, n] = overlap(mps1,mps2, hset)
[M, N] = size(hset); d = size(mps1{1}, 3);
% expectation value
e=0;
for m = 1:M
em=1;
for j = N:-1:1
h = hset{m, j};
h = reshape(h, [1, 1, d, d]);
em = updateCright(em, mps1{j}, h, mps2{j});
end
e=e+em;
end

% norm
n1=1;
X = eye(d); X = reshape(X, [1, 1, d, d]); 
for j = N:-1:1
n1 = updateCright(n1, mps1{j}, X, mps1{j});
end

n2=1;
X = eye(d); X = reshape(X, [1, 1, d, d]); 
for j = N:-1:1
n2 = updateCright(n2, mps2{j}, X, mps2{j});
end
e=e/sqrt(n1*n2);