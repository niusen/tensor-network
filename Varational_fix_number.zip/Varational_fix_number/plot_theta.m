clc;clear;close all;
load SOC_twosite_L_160_n_40_D_100_U_1_delta_0.mat;
figure

f1=plot(kl/pi,theta,'r.-');hold on;
nn=correlation(:,2,2)+correlation(:,1,1);

f2=plot(kl/pi,real(nn),'b.-');hold on;
set(gca,'FontSize',18);

xlabel('$k/\pi$','Interpreter','latex','FontSize',25);
le=legend([f1,f2],'\theta (k)','n(k)','location','northeast');
set(le,'FontSize',20);
axis([0,2,0,1.3]);
%text(-0.8,1.3,'$m_z=-1kHz$','Interpreter','latex','FontSize',18,'Fontname','Arial');




