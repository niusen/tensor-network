function distri=qn(q,ds)
%return the quantum number of the bonds
distri=zeros(1,sum(ds));
for c1=1:length(q)
    a1=sum(ds(1:c1-1))+1;
    a2=sum(ds(1:c1));
    distri(a1:a2)=q(c1)*ones(1,a2-a1+1);
end

