function M=direct_sum(A,B)
[m1,n1]=size(A);
[m2,n2]=size(B);
M=zeros(m1+m2,n1+n2);
M(1:m1,1:n1)=A;
M(m1+1:m1+m2,n1+1:n1+n2)=B;
