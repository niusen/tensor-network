clc;clear;
L=8;%size
n=2;%particle number
D=100;%bond
alpha_type=2;%subspace expansion
two_site=0;%two-site dmrg

t=0;
t0=1;
U=1;
lamda=0.5;
delta=0.0;

if alpha_type==1
    alpha=0.5;
elseif alpha_type==2
    alpha=[];
end


for c1=2:4
SOC(L*c1,n*c1,D,alpha,t,t0,U,lamda,delta,two_site)
end
