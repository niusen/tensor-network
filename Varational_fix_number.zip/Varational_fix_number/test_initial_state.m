clc;clear;
L=6;D=10;n=4;
mps0=createrandommps_qn(L, D, n);
mps0=mps0(1,:);

sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);
sp=(sx+i*sy)/2;sm=(sx-i*sy)/2;np=(eye(2)-sz)/2;


two_body=cell(2*L,2*L);
M=cell(1);for c1=1:2*L;M{1,c1}=eye(2);end
for ca=1:2*L
    for cb=1:2*L
        MM=M;
        for cj=min(ca,cb)+1:max(ca,cb)-1%the distance between ca and cb is at least 2
            MM{1,cj}=sz;
        end
        
        if ca<cb
            MM{1,ca}=sp;MM{1,cb}=sm;
        elseif ca==cb
            MM{1,ca}=np;
        elseif ca>cb
            MM{1,ca}=sm;MM{1,cb}=sp;
        end
       MMM=cell(1); 
        for cj=1:L
            MMM{1,cj}=reshape(kron(MM{1,2*cj-1},MM{1,2*cj}),[1,1,4,4]);
        end
        two_body{ca,cb}=MMM;
        
    end
end
M=two_body;
two_body=cell(1);
for ca=1:2*L
    for cb=1:2*L
        two_body{(ca+mod(ca,2))/2,(cb+mod(cb,2))/2,2-mod(ca,2),2-mod(cb,2)}=M{ca,cb};
    end
end


%observable
for c1=1:L
    for c2=1:L
        for cs1=1:2
            for cs2=1:2
                ob(c1,c2,cs1,cs2)=overlap_1D(mps0,mpo_mps(two_body{c1,c2,cs1,cs2},mps0))/overlap_1D(mps0,mps0);
            end
        end
    end
end

%momentum occupation
correlation=zeros(L,2,2);
for c1=1:L
    kl(c1)=2*pi*c1/L;
    for ca=1:L
        for cb=1:L
            for cs1=1:2
                for cs2=1:2
                    correlation(c1,cs1,cs2)=correlation(c1,cs1,cs2)+1/L*exp(i*kl(c1)*(ca-cb))*ob(ca,cb,cs1,cs2);
                end
            end
        end
    end
end
 
n_total=sum(correlation(:,1,1))+sum(correlation(:,2,2))