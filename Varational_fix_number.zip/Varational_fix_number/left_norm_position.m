function mps=left_norm_position(mps,p1,p2)
%the modula of mps should not be changed
%from right to left
%p1>p2,p1<N
N=size(mps,2);
for c1=p1:-1:p2
M=mps{1,c1};[D1,D2,d]=size(M); 
M=permute(M,[1,3,2]);M=reshape(M,[D1,d*D2]); 
[U,S,B]=svd2(M);DB=size(S, 1);
B=reshape(B,[DB,d,D2]); B=permute(B,[1,3,2]); 
mps{1,c1}=B;
US=U*S;
mps{1,c1-1}=contracttensors(mps{1,c1-1},3,2,US,2,1); 
mps{1,c1-1}=permute(mps{1,c1-1},[1,3,2]);
end
