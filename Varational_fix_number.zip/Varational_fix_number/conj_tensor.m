function y=conj_tensor(mps)
[m,n]=size(mps);
y=cell(m,n);
for c1=1:m
    for c2=1:n
        y{c1,c2}=conj(mps{c1,c2});
    end
end