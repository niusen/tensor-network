function A=left_permute(M)
[D1,D2,d]=size(M);
M=permute(M,[1,3,2]);
A=reshape(M,[D1*d,D2]);