function newmpo=adding_mpo(mpo1,mpo2,coeficient)
M=size(mpo1,2);
newmpo=cell(1,M);

cm=1;
[Dl1,Dr1,da1,db1]=size(mpo1{1,cm});
[Dl2,Dr2,da2,db2]=size(mpo2{1,cm});
mm=zeros(1,Dr1+Dr2,da1,db1);
mm(1,1:Dr1,:,:)=mpo1{1,cm}*coeficient(1);
mm(1,Dr1+1:Dr1+Dr2,:,:)=mpo2{1,cm}*coeficient(2);
newmpo{1,cm}=mm;

for cm=2:M-1
    
[Dl1,Dr1,da1,db1]=size(mpo1{1,cm});
[Dl2,Dr2,da2,db2]=size(mpo2{1,cm});
mm=zeros(Dl1+Dl2,Dr1+Dr2,da1,db1);
mm(1:Dl1,1:Dr1,:,:)=mpo1{1,cm};
mm(Dl1+1:Dl1+Dl2,Dr1+1:Dr1+Dr2,:,:)=mpo2{1,cm};
newmpo{1,cm}=mm;   
    
    
    
    
end

cm=M;
[Dl1,Dr1,da1,db1]=size(mpo1{1,cm});
[Dl2,Dr2,da2,db2]=size(mpo2{1,cm});
mm=zeros(Dl1+Dl2,1,da1,db1);
mm(1:Dl1,1,:,:)=mpo1{1,cm};
mm(Dl1+1:Dl1+Dl2,1,:,:)=mpo2{1,cm};
newmpo{1,cm}=mm;
