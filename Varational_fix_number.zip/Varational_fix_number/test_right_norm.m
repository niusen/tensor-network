clc;clear;
randn('state', 0);%
D1=6;D2=5;d=4;
a=randn(D1,D2,d);%D1:0 1 2, d:0 1, D2:0 1 2 3
M=zeros(D1,D2,d);
qR=[1,2,3];
dsR=[2,1,2];

qL=[2,3,4,7];
dsL=[1,2,2,1];

nd=[0 1 1 2];

for cl=1:length(qL)
    for cr=1:length(qR)
        for cd=1:d
            if qL(cl)-nd(cd)==qR(cr)
                M(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd)=a(sum(dsL(1:cl-1))+1:sum(dsL(1:cl)),sum(dsR(1:cr-1))+1:sum(dsR(1:cr)),cd);
            end
        end
    end
end

M=permute(M,[1,3,2]);
M=reshape(M,[D1*d,D2]);%M=[M(:,:,1),M(:,:,2),M(:,:,3),M(:,:,4)];
qLd=[qL-nd(1),qL-nd(2),qL-nd(3),qL-nd(4)];%the grouped indice
dsLd=[dsL,dsL,dsL,dsL];

[u s v]=svd2(M);

qLd_new=unique(qLd);
r_order=[];
for c1=1:length(qLd_new)
    for c2=1:length(qLd)
        if qLd_new(c1)==qLd(c2)
            r_order=[r_order,sum(dsLd(1:c2-1))+1:sum(dsLd(1:c2))];
        end
    end
    
end


for c1=1:length(qLd_new)
    dsLd_new(c1)=sum(dsLd(find(qLd==qLd_new(c1))));
end


MM=M(r_order,:);
R_order=eye(length(r_order));
R_order=R_order(r_order,:);

[u,s,v,qL_newnew,dsL_newnew,qR_newnew,dsR_newnew]=svd_qn(MM,qLd_new,dsLd_new,qR,dsR);
u*s*v-MM
qL_newnew
dsL_newnew
qR_newnew
dsR_newnew
u=R_order'*u;

v=s*v;
D2=size(u,2);
u=permute(u,[1,3,2]);
u=reshape(u,[D1,D2,d]);

 