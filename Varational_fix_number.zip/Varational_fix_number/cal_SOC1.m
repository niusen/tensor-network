clc;clear;
L=40;%size
n=10;%particle number
D=100;%bond
alpha_type=2;%subspace expansion
two_site=1;%two-site dmrg

t=0;
t0=1;
U=1;
lamda=0.5;
delta=0.0;

if alpha_type==1
    alpha=0.5;
elseif alpha_type==2
    alpha=[];
end


for c1=1:2
SOC(L*2^(c1-1),n*2^(c1-1),D,alpha,t,t0,U,lamda,delta,two_site)

end