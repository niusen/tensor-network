function [A0,BP,Qn,ds]=sub_exp_rl(alpha,mpsl,mpsr,Hright,W,QL,DsL,QR,DsR)
%subspace expansion right to left
%mpsl: mps{1,j-1}
%mpsr: mps{1,j}
%W: MPO on site i
%QL: QL{1,j}
%QR: QR{1,j}

B=mpsr;[Dl_b,Dr_b,d_b]=size(B);B=reshape(B,[Dl_b,Dr_b*d_b]);
Hright_mpo=contracttensors(W,4,2,Hright{1,1},3,2);
Pm=contracttensors(Hright_mpo,5,[3,5],mpsr,3,[3,2]);%w,d,Dr,Dl
Pm=permute(Pm,[1,4,3,2]);%w,Dl,Dr,d
[w,Dl,Dr,d]=size(Pm);Pm=reshape(Pm,[w*Dl,Dr*d]);%w*Dl,Dr*d
dstDr=qn(QR,DsR);dstDr=repmat(dstDr',[1,d]);
dstd=[0,1,1,2];dstd=repmat(dstd',[1,Dr]);dstd=permute(dstd,[2,1]);
dstDl=qn(QL,DsL);dstDl=repmat(dstDl',[1,w]);dstDl=permute(dstDl,[2,1]);
mpo_q=-[0,1,-1,1,-1,1,-1,1,-1,0,1,-1,1,-1,1,-1,1,-1];mpo_ds=ones(1,18);
dstw=qn(mpo_q,mpo_ds);dstw=repmat(dstw',[1,Dl]);
basis_l=dstDl+dstw;basis_l=reshape(basis_l,[1,Dl*w]);
basis_r=dstDr+dstd;basis_r=reshape(basis_r,[1,Dr*d]);

%check the quantum numbers
% for ca=1:Dl*w
%     for cb=1:d*Dr
%         if abs(Pm(ca,cb))>0
%             a=[basis_l(ca),basis_r(cb)]
%             if abs(a(1)-a(2))>0
%                 a
%             end
%         end
%     end
% end
%%%


BP=[B;alpha*Pm];
A0=zeros(size(mpsl,1),size(BP,1),size(mpsl,3));A0(1:size(mpsl,1),1:size(mpsl,2),1:size(mpsl,3))=mpsl;
A0=permute(A0,[1,3,2]);A0=reshape(A0,[size(A0,1)*size(A0,2),size(A0,3)]);
%check the state is invariant
%BP=reshape(BP,[w*Dl+Dl,Dr,d]);
%mps1=mps;mps1{1,j}=BP;mps1{1,j-1}=A0;overlap_1D(mps1,mps)/sqrt(overlap_1D(mps,mps)*overlap_1D(mps1,mps1))
%%%%%%%%%%


%sort the quantum numbers
Qns=[qn(QL,DsL),basis_l];
[order,Qn,ds]=sort_qn(Qns);
BP=BP(order,:);
R_order=eye(length(order));
R_order=R_order(order,:);
A0=A0*R_order';
basis_l=qn(Qn,ds);
QL=Qn;
DsL=ds;
%%%%%%
%check the quantum numbers

% for ca=1:length(basis_l)
%     for cb=1:length(basis_r)
%         if abs(BP(ca,cb))>0           
%             a=[basis_l(ca),basis_r(cb)]
%             if abs(a(1)-a(2))>0                
%             end
%         end
%     end
% end



[order,QR_new,DsR_new]=sort_qn(basis_r);
BP=BP(:,order);
R_order=eye(length(order));
R_order=R_order(:,order);
%BP=BP*R_order';%turn back the order

% step=1;
% for c1=1:length(QL_new)
%     c2=find(QL_new(c1)*ones(1,length(Qn))==Qn);
%     if length(c2)>0
%     nl(step)=c1;nr(step)=c2;
%     step=step+1;
%     end
% end

[u,s,v,Qn,ds]=svd_trun_qn(BP,size(mpsr,1),QL,DsL,QR_new,DsR_new);


v=v*R_order';
BP=reshape(v,[Dl_b,Dr_b,d_b]);
u=u*s;A0=A0*u;
A0=reshape(A0,[size(mpsl,1),size(mpsl,3),size(A0,2)]);
A0=permute(A0,[1,3,2]);








