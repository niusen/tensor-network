function [u,s,v,qL_new,dsL_new,qR_new,dsR_new]=svd_qn(MM,qL,dsL,qR,dsR)

%The M matrix has non-zero blocks when qL(c1)=qR(c2)
%The program returns the quantum number for column indice of u and row indice of v matrice 
%Note that in both qL and qR the quantum numbers should not appear more
%than once

u=[];s=[];v=[];
mark_m=zeros(length(qL),length(qR));%mark the non-zero block
step=1;
keep_L=[];keep_R=[];
D1l=[];D1r=[];
D2l=[];D2r=[];
for c1=1:length(qL)
    for c2=1:length(qR)
        if qL(c1)==qR(c2)
           mark_m(c1,c2)=1;
           [u1 s1 v1]=svd2(MM(sum(dsL(1:c1-1))+1:sum(dsL(1:c1)),sum(dsR(1:c2-1))+1:sum(dsR(1:c2))));
           %[u1 s1 v1]=svd(MM(sum(dsL(1:c1-1))+1:sum(dsL(1:c1)),sum(dsR(1:c2-1))+1:sum(dsR(1:c2))));v1=v1';
           u=direct_sum(u,u1);D1l=[D1l,size(u1,1)];D1r=[D1r,size(u1,2)];%the non-zero blocks
           s=direct_sum(s,s1);
           v=direct_sum(v,v1);D2l=[D2l,size(v1,1)];D2r=[D2r,size(v1,2)];%the non-zero blocks
           keep_L=[keep_L,c1];
           keep_R=[keep_R,c2];
           step=step+1;
        end
    end
end



%add zero columns
columns=cell(1,length(qR));
qR_new=[];
dsR_new=[];
step=1;
for c1=1:length(qR)
     %qR_new=[qR_new,qR(c1)];
     if sum(c1==keep_R)>0
         columns{1,c1}=v(:,sum(D2r(1:step-1))+1:sum(D2r(1:step)));
         qR_new=[qR_new,qR(c1)];
         dsR_new=[dsR_new,D2l(step)];
         step=step+1;
     else
         %dsR_new=[dsR_new,dsR(c1)];
         columns{1,c1}=zeros(size(v,1),dsR(c1));
     end
end
v=[];
for c1=1:length(qR)
    v=[v,columns{1,c1}];
end
    
    
%add zero rows 
columns=cell(1,length(qL));
qL_new=[];
dsL_new=[];
step=1;
for c1=1:length(qL)
     %qL_new=[qL_new,qL(c1)];
     if sum(c1==keep_L)>0
         columns{1,c1}=u(sum(D1l(1:step-1))+1:sum(D1l(1:step)),:);
         qL_new=[qL_new,qL(c1)];
         dsL_new=[dsL_new,D1r(step)];
         step=step+1;
     else
         %dsL_new=[dsL_new,dsL(c1)];
         columns{1,c1}=zeros(dsL(c1),size(u,2));
     end
end
u=[];
for c1=1:length(qL)
    u=[u;columns{1,c1}];
end   
    
   
%keep the u and v to be square matrix
ss=zeros(size(MM,1),size(MM,2));
ss(1:size(u,2),1:size(v,1))=s;
s=ss;

if size(u,1)>size(u,2)
    xx=size(u,1)-size(u,2);
    u=[u,zeros(size(u,1),size(u,1)-size(u,2))];
    dsL_new(length(dsL_new))=dsL_new(length(dsL_new))+xx;
end
if size(v,2)>size(v,1)
    yy=size(v,2)-size(v,1);
    v=[v;zeros(size(v,2)-size(v,1),size(v,2))];
    dsR_new(length(dsR_new))=dsR_new(length(dsR_new))+yy;
end


