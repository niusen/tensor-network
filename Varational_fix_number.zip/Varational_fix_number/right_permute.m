function B=right_permute(M)
[D1,D2,d]=size(M);
B=reshape(M,[D1,D2*d]);