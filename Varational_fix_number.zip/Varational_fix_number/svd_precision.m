%Economical SVD:
function [U, S, V] = svd_precision(T,precision)
[m, n] = size(T);
if m >=n,[U,S,V]=svd(T,0); else [V,S,U]=svd(T',0); end
V=V';

SS=diag(S);SS=SS.^2;SS=SS/sum(SS);

weight=0;
step=0;
for c1=1:length(SS)
    weight=weight+SS(c1);
    step=step+1;
    if weight>1-precision
        break;
    end
end

U=U(:,1:step);
S=S(1:step,1:step);
V=V(1:step,:);