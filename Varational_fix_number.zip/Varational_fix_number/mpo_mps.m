function mps1=mpo_mps(mpo,mps1)
%mpo���õ�mps
M=size(mps1,2);
    for ccm=1:M
        if isempty(mpo{1,ccm})
            continue;
        end
        mps1{1,ccm}=contracttensors(mpo{1,ccm},4,4,mps1{1,ccm},3,3);%Dul,Dur,d,Ddl,Ddr
        [Dul,Dur,d,Ddl,Ddr]=size(mps1{1,ccm});
        mps1{1,ccm}=permute(mps1{1,ccm},[1,4,2,5,3]);%Dul,Ddl,Dur,Ddr,d
        mps1{1,ccm}=reshape(mps1{1,ccm},[Dul*Ddl,Dur*Ddr,d]); 
    end
  