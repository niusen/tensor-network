function mps_total=left_norm_position_qn(mps_total,p1,p2)
%the modula of mps should not be changed
%from right to left
%p1>p2,p1<N
L=size(mps_total,2);
mps=mps_total(1,1:L);
QL=mps_total(2,1:L);
QR=mps_total(3,1:L);
DsL=mps_total(4,1:L);
DsR=mps_total(5,1:L);

%perform the svd in each blocks
%Ql=nd+Qr
for ci=p1:-1:p2
    
M=mps{1,ci};
[D1,D2,d]=size(M);
qR=QR{1,ci};
dsR=DsR{1,ci};
qL=QL{1,ci};
dsL=DsL{1,ci};

nd=[0 1 1 2];

M=reshape(M,[D1,D2*d]);%M=[M(:,:,1),M(:,:,2),M(:,:,3),M(:,:,4)];
qRd=[qR+nd(1),qR+nd(2),qR+nd(3),qR+nd(4)];%the grouped indice
dsRd=[dsR,dsR,dsR,dsR];


qRd_new=unique(qRd);
r_order=[];
for c1=1:length(qRd_new)
    for c2=1:length(qRd)
        if qRd_new(c1)==qRd(c2)
            r_order=[r_order,sum(dsRd(1:c2-1))+1:sum(dsRd(1:c2))];
        end
    end
    
end

for c1=1:length(qRd_new)
    dsRd_new(c1)=sum(dsRd(find(qRd==qRd_new(c1))));
end


MM=M(:,r_order);
R_order=eye(length(r_order));
R_order=R_order(:,r_order);

[u,s,v,qL_newnew,dsL_newnew,qR_newnew,dsR_newnew]=svd_qn(MM,qL,dsL,qRd_new,dsRd_new);



v=v*R_order';
if size(s,2)>size(s,1)%discard useless states
    s=s(:,1:size(s,1));
    v=v(1:size(s,1),:);
end
u=u*s;
v=reshape(v,[size(v,1),D2,d]);
mps{1,ci}=v;
u=contracttensors(mps{1,ci-1},3,2,u,2,1); 
u=permute(u,[1,3,2]);
mps{1,ci-1}=u;   

QL{1,ci}=qL_newnew;
DsL{1,ci}=dsL_newnew;
QR{1,ci-1}=qL_newnew;
DsR{1,ci-1}=dsL_newnew;
    
end


mps_total(1,1:L)=mps;
mps_total(2,1:L)=QL;
mps_total(3,1:L)=QR;
mps_total(4,1:L)=DsL;
mps_total(5,1:L)=DsR;













