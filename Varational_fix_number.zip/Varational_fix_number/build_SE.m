clc;clear;
load MPO;
hset=MPO;
D=20;precision=1e-5;
n=7;
%function [E, mps] = minimizeE_SE(hset,n, D, precision)
%Subspace expansion, ref:PHYSICAL REVIEW B 91, 155115 (2015)

[M, N] = size(hset);
mps0 = createrandommps_qn(N, D, n);
d=4;
mps0 = left_norm_qn(mps0);
mps=mps0(1,:);
QL=mps0(2,:);
QR=mps0(3,:);
DsL=mps0(4,:);
DsR=mps0(5,:);

for j=1:10
er=test_block(mps{1,j},QL{1,j},DsL{1,j},QR{1,j},DsR{1,j})
end


% storage-initialization

Hstorage = initHstorage_mpo(mps, hset, d);%������������,��ֻ��ʼ������2��site����һ��site����Ҫ�㣬��Ϊ����sweep��ʱ��ӵ�һ��site��ʼ�����⣬������һ��sweep�Ǵ������ң�Hleft = Hstorage(:, 1)=1��������Ҫ��;
%ע�⣬Hstorage_i��ָ����ͣ����site i-1 �� site i֮���ָ��D_{i-1}, D_{i-1}'


% optimization sweeps 
%while 1
Evalues = [];
% ********* cycle 1: j ! j ? 1 (from 1 to N   1)********* 
for j=1:N-1%���µ���N-1��site
    %j
% optimization,��������

%mps1=mps;save mps1 mps1;


Hleft = Hstorage(:, j);%Hleft��Ȼ��cell,��j=1��ʼ
Hright = Hstorage(:, j + 1);
hsetj = hset(:, j);

1

[A, E] = minimizeE_onesite(hsetj, Hleft, Hright,QL{1,j},DsL{1,j},QR{1,j},DsR{1,j},n); 
%E
[mps{1,j},mps{1,j+1},qR_newnew,dsR_newnew]=right_norm_onesite(A,mps{1,j+1},QL{1,j},DsL{1,j},QR{1,j},DsR{1,j});
QL{1,j+1}=qR_newnew;
DsL{1,j+1}=dsR_newnew;
QR{1,j}=qR_newnew;
DsR{1,j}=dsR_newnew;
Evalues = [Evalues, E];E

%subspace expansion
alpha=0;%1e-4;
%mps0=mps;


[mps{1,j},mps{1,j+1},Qn,ds]=sub_exp_lr(alpha,mps{1,j},mps{1,j+1},Hleft,hset{1,j},QL{1,j},DsL{1,j},QR{1,j},DsR{1,j});
QL{1,j+1}=Qn;
DsL{1,j+1}=ds;
QR{1,j}=Qn;
DsR{1,j}=ds;


er=test_block(mps{1,j},QL{1,j},DsL{1,j},QR{1,j},DsR{1,j})


%QL{1,j+1}
%DsL{1,j+1}
%check the state is invariant
%overlap_1D(mps0,mps)/sqrt(overlap_1D(mps,mps)*overlap_1D(mps0,mps0))

%%%%%%%%%%

% storage-update
for m=1:M
h =hset{m, j};
Hstorage{m, j + 1} = updateCleft(Hleft{m}, mps{1,j}, h, mps{1,j}); %�������Ҹ���
end

end

% ****************** cycle 2: j = j+  1 (from N to 2) ****************** 
% for j = N:(-1):2
% %j
% % minimization
% Hleft = Hstorage(:, j);
% Hright = Hstorage(:, j + 1);
% hsetj = hset(:, j);
% 
% 
% 
% [A, E] = minimizeE_onesite(hsetj, Hleft, Hright,QL{1,j},DsL{1,j},QR{1,j},DsR{1,j},n); 
% %E
% [mps{1,j-1},mps{1,j},qR_newnew,dsR_newnew]=left_norm_onesite(mps{1,j-1},A,QL{1,j},DsL{1,j},QR{1,j},DsR{1,j});
% QL{1,j}=qR_newnew;
% DsL{1,j}=dsR_newnew;
% QR{1,j-1}=qR_newnew;
% DsR{1,j-1}=dsR_newnew;
% 
% Evalues = [Evalues, E];
% % storage-update 
% for m=1:M
% h = hset{m, j};
% Hstorage{m, j} = updateCright(Hright{m}, mps{1,j}, h, mps{1,j});
% end
% 
% end

% if (std(Evalues)/abs(mean(Evalues)) < precision) 
% 
% break;
% end
% 
% end






% ******************** one-site optimization *********************** 
function [A, E] = minimizeE_onesite(hsetj, Hleft, Hright,qL,dsL,qR,dsR,n)
DAl = size(Hleft{1}, 1); 
DAr = size(Hright{1}, 1);
d = size(hsetj{1}, 1);
% calculation of Heff 
M=size(hsetj, 1);
Heff = 0;
for m = 1:M%shollwock(189)ʽ������ֻ����ĵ��������b_lֻ��Ϊ1.
Heffm=contracttensors(Hleft{m},3,2,hsetj{m},4,1);%Dl1,Dl3,D2,da,db
Heffm=contracttensors(Heffm,5,3,Hright{m},3,2);%Dl1,Dl3,da,db, Dr1,Dr3
Heffm=permute(Heffm,[1,5,3,2,6,4]);
[Dl1,Dr1,da,Dl3,Dr3,db]=size(Heffm);
Heffm=reshape(Heffm,[Dl1*Dr1*da,Dl3*Dr3*db]);    
Heff = Heff + Heffm;
end


%al=1:16;
%al=reshape(al,[Dl1,Dr1,da]);
dstL=qn(qL,dsL);dstLp=n-dstL;dstLp=repmat(dstLp',[1,Dr1,da]);
dstR=qn(qR,dsR);dstR=repmat(dstR,[Dl1,1,da]);
dstd=[0,1,1,2];dstd=repmat(dstd,[Dl1,1,Dr1]);dstd=permute(dstd,[1,3,2]);
basis_qn=dstLp+dstR+dstd;
basis_qn=reshape(basis_qn,[1,Dl1*Dr1*da]);
posit=find(basis_qn==n*ones(1,Dl1*Dr1*da));

H=zeros(length(posit),length(posit));
for c1=1:length(posit)
    for c2=1:length(posit)
        H(c1,c2)=Heff(posit(c1),posit(c2));
    end
end

%size(H)

% optimization
options.disp = 0;
%Heff;
[A, E] = eigs(H, 1, 'sr', options); 
AA=zeros(1,Dl1*Dr1*da);
for c1=1:length(posit)
    AA(posit(c1))=A(c1);
end
A=AA;
A = reshape(A, [Dl1,Dr1,da]);
end




function [mpsl,mpsr,qR_newnew,dsR_newnew]=right_norm_onesite(mpsl,mpsr,qL,dsL,qR,dsR)
%the modula of mps should not be changed
%from left to right

%perform the svd in each blocks
%Ql-nd=Qr

    
M=mpsl;
[D1,D2,d]=size(M);


nd=[0 1 1 2];

M=permute(M,[1,3,2]);
M=reshape(M,[D1*d,D2]);%M=[M(:,:,1),M(:,:,2),M(:,:,3),M(:,:,4)];
qLd=[qL-nd(1),qL-nd(2),qL-nd(3),qL-nd(4)];%the grouped indice
dsLd=[dsL,dsL,dsL,dsL];

qLd_new=unique(qLd);
r_order=[];
for c1=1:length(qLd_new)
    for c2=1:length(qLd)
        if qLd_new(c1)==qLd(c2)
            r_order=[r_order,sum(dsLd(1:c2-1))+1:sum(dsLd(1:c2))];
        end
    end
    
end

for c1=1:length(qLd_new)
    dsLd_new(c1)=sum(dsLd(find(qLd==qLd_new(c1))));
end


MM=M(r_order,:);
R_order=eye(length(r_order));
R_order=R_order(r_order,:);

[u,s,v,qL_newnew,dsL_newnew,qR_newnew,dsR_newnew]=svd_qn(MM,qLd_new,dsLd_new,qR,dsR);



u=R_order'*u;
if size(s,1)>size(s,2)%discard useless states
    s=s(1:size(s,2),:);
    u=u(:,1:size(s,2));
end
v=s*v;
D2=size(u,2);
u=reshape(u,[D1,d,D2]);
u=permute(u,[1,3,2]);
mpsl=u;
v=contracttensors(v,2,2,mpsr,3,1); 
mpsr=v;   


    
end



function [mpsl,mpsr,qL_newnew,dsL_newnew]=left_norm_onesite(mpsl,mpsr,qL,dsL,qR,dsR)
%the modula of mps should not be changed
%from right to left


%perform the svd in each blocks
%Ql=nd+Qr
  
M=mpsr;
[D1,D2,d]=size(M);

nd=[0 1 1 2];

M=reshape(M,[D1,D2*d]);%M=[M(:,:,1),M(:,:,2),M(:,:,3),M(:,:,4)];
qRd=[qR+nd(1),qR+nd(2),qR+nd(3),qR+nd(4)];%the grouped indice
dsRd=[dsR,dsR,dsR,dsR];


qRd_new=unique(qRd);
r_order=[];
for c1=1:length(qRd_new)
    for c2=1:length(qRd)
        if qRd_new(c1)==qRd(c2)
            r_order=[r_order,sum(dsRd(1:c2-1))+1:sum(dsRd(1:c2))];
        end
    end
    
end

for c1=1:length(qRd_new)
    dsRd_new(c1)=sum(dsRd(find(qRd==qRd_new(c1))));
end


MM=M(:,r_order);
R_order=eye(length(r_order));
R_order=R_order(:,r_order);

[u,s,v,qL_newnew,dsL_newnew,qR_newnew,dsR_newnew]=svd_qn(MM,qL,dsL,qRd_new,dsRd_new);



v=v*R_order';
if size(s,2)>size(s,1)%discard useless states
    s=s(:,1:size(s,1));
    v=v(1:size(s,1),:);
end
u=u*s;
v=reshape(v,[size(v,1),D2,d]);
mpsr=v;
u=contracttensors(mpsl,3,2,u,2,1); 
u=permute(u,[1,3,2]);
mpsl=u;   


    
end





