function mps=right_norm_position(mps,p1,p2)
%the modula of mps should not be changed
%from left to right
%p1<p2,p2<N
N=size(mps,2);
for c1=p1:p2
M=mps{1,c1};[D1,D2,d]=size(M); 
M=permute(M,[3,1,2]);M=reshape(M,[d*D1,D2]); 
[U,S,B]=svd2(M);DB=size(S, 1);
U=reshape(U,[d,D1,DB]); U=permute(U,[2,3,1]); 
mps{1,c1}=U;
SB=S*B;
mps{1,c1+1}=contracttensors(SB,2,2,mps{1,c1+1},3,1); 
end







