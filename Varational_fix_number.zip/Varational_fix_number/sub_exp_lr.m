function [AP,B0,Qn,ds]=sub_exp_lr(alpha,mpsl,mpsr,Hleft,W,QL,DsL,QR,DsR)
%subspace expansion left to right
%mpsl: mps{1,j}
%mpsr: mps{1,j+1}
%W: MPO on site i
%QL: QL{1,j}
%QR: QR{1,j}

A=mpsl;[Dl_a,Dr_a,d_a]=size(A);A=permute(A,[1,3,2]);A=reshape(A,[Dl_a*d_a,Dr_a]);
Hleft_mpo=contracttensors(Hleft{1,1},3,2,W,4,1);
Pm=contracttensors(Hleft_mpo,5,[2,5],mpsl,3,[1,3]);%Dl,w,d,Dr
Pm=permute(Pm,[1,2,4,3]);%Dl,w,Dr,d
[Dl,w,Dr,d]=size(Pm);Pm=permute(Pm,[1,4,2,3]);Pm=reshape(Pm,[Dl*d,w*Dr]);%Dl*d,w*Dr
dstDl=qn(QL,DsL);dstDl=repmat(dstDl',[1,d]);
dstd=[0,1,1,2];dstd=repmat(dstd',[1,Dl]);dstd=permute(dstd,[2,1]);
dstDr=qn(QR,DsR);dstDr=repmat(dstDr',[1,w]);dstDr=permute(dstDr,[2,1]);
mpo_q=[0,1,-1,1,-1,1,-1,1,-1,0,1,-1,1,-1,1,-1,1,-1];mpo_ds=ones(1,18);
dstw=qn(mpo_q,mpo_ds);dstw=repmat(dstw',[1,Dr]);
basis_l=dstDl-dstd;basis_l=reshape(basis_l,[1,Dl*d]);
basis_r=dstDr-dstw;basis_r=reshape(basis_r,[1,w*Dr]);

%check the quantum numbers
% for ca=1:Dl*d
%     for cb=1:w*Dr
%         if abs(Pm(ca,cb))>0
%             a=[basis_l(ca),basis_r(cb)];
%             if abs(a(1)-a(2))>0
%                 a
%             end
%         end
%     end
% end
%%%%


AP=[A,alpha*Pm];
B0=zeros(size(AP,2),size(mpsr,2),size(mpsr,3));B0(1:size(mpsr,1),1:size(mpsr,2),1:size(mpsr,3))=mpsr;
B0=reshape(B0,[size(B0,1),size(B0,2)*size(B0,3)]);
%check the state is invariant
%AP=reshape(AP,[Dl,d,Dr+w*Dr]);AP=permute(AP,[1,3,2]);
%mps1=mps;mps1{1,j}=AP;mps1{1,j+1}=B0;overlap_1D(mps1,mps)/sqrt(overlap_1D(mps,mps)*overlap_1D(mps1,mps1))
%%%%%%%%%%


%sort the quantum numbers
Qns=[qn(QR,DsR),basis_r];
[order,Qn,ds]=sort_qn(Qns);
AP=AP(:,order);
R_order=eye(length(order));
R_order=R_order(:,order);
B0=R_order'*B0;
basis_r=qn(Qn,ds);
QR=Qn;
DsR=ds;
%%%%%%
%check the quantum numbers

% for ca=1:length(basis_l)
%     for cb=1:length(basis_r)
%         if abs(AP(ca,cb))>0           
%             a=[basis_l(ca),basis_r(cb)]
%             if abs(a(1)-a(2))>0                
%             end
%         end
%     end
% end



[order,QL_new,DsL_new]=sort_qn(basis_l);
AP=AP(order,:);
R_order=eye(length(order));
R_order=R_order(order,:);
%AP=R_order'*AP;%turn back the order

% step=1;
% for c1=1:length(QL_new)
%     c2=find(QL_new(c1)*ones(1,length(Qn))==Qn);
%     if length(c2)>0
%     nl(step)=c1;nr(step)=c2;
%     step=step+1;
%     end
% end

[u,s,v,Qn,ds]=svd_trun_qn(AP,size(mpsl,2),QL_new,DsL_new,QR,DsR);
%sum(sum(abs(u*s*v-AP)))


u=R_order'*u;
u=reshape(u,[Dl_a,d_a,size(u,2)]);AP=permute(u,[1,3,2]);
v=s*v;B0=contracttensors(v,2,2,B0,3,1);B0=reshape(B0,[size(B0,1),size(mpsr,2),size(mpsr,3)]);









