function mps_total=right_norm_qn(mps_total)
%from left to right

L=size(mps_total,2);
mps=mps_total(1,1:L);
QL=mps_total(2,1:L);
QR=mps_total(3,1:L);
DsL=mps_total(4,1:L);
DsR=mps_total(5,1:L);

%perform the svd in each blocks
%Ql-nd=Qr
for ci=1:L-1
    
M=mps{1,ci};
[D1,D2,d]=size(M);
qR=QR{1,ci};
dsR=DsR{1,ci};
qL=QL{1,ci};
dsL=DsL{1,ci};

nd=[0 1 1 2];

M=permute(M,[1,3,2]);
M=reshape(M,[D1*d,D2]);%M=[M(:,:,1),M(:,:,2),M(:,:,3),M(:,:,4)];
qLd=[qL-nd(1),qL-nd(2),qL-nd(3),qL-nd(4)];%the grouped indice
dsLd=[dsL,dsL,dsL,dsL];

qLd_new=unique(qLd);
r_order=[];
for c1=1:length(qLd_new)
    for c2=1:length(qLd)
        if qLd_new(c1)==qLd(c2)
            r_order=[r_order,sum(dsLd(1:c2-1))+1:sum(dsLd(1:c2))];
        end
    end
    
end

for c1=1:length(qLd_new)
    dsLd_new(c1)=sum(dsLd(find(qLd==qLd_new(c1))));
end


MM=M(r_order,:);
R_order=eye(length(r_order));
R_order=R_order(r_order,:);

[u,s,v,qL_newnew,dsL_newnew,qR_newnew,dsR_newnew]=svd_qn(MM,qLd_new,dsLd_new,qR,dsR);



u=R_order'*u;
if size(s,1)>size(s,2)%discard useless states
    s=s(1:size(s,2),:);
    u=u(:,1:size(s,2));
end
v=s*v;
D2=size(u,2);
u=reshape(u,[D1,d,D2]);
u=permute(u,[1,3,2]);
mps{1,ci}=u;
v=contracttensors(v,2,2,mps{1,ci+1},3,1); 
mps{1,ci+1}=v;   

QL{1,ci+1}=qR_newnew;
DsL{1,ci+1}=dsR_newnew;
QR{1,ci}=qR_newnew;
DsR{1,ci}=dsR_newnew;
    
end

%normalize
A=mps{1,L};
[D1,D2,d]=size(A);
A=reshape(A,[D1*d,1]);
ov=A'*A;
mps{1,L}=mps{1,L}/sqrt(ov);


mps_total(1,1:L)=mps;
mps_total(2,1:L)=QL;
mps_total(3,1:L)=QR;
mps_total(4,1:L)=DsL;
mps_total(5,1:L)=DsR;









