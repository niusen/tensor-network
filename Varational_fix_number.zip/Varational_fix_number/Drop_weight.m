function [A,wn]=Drop_weight(A,wn)
discard=1e-5;
A=A/sum(A)/(wn(2)-wn(1));%normalize the spectra
dw=wn(2)-wn(1);
for c1=1:length(wn)
    if (sum(A(1:c1))*dw)>=discard
       break;
    else
       if (sum(A(1:c1+1))*dw)>=discard
           if c1>1
              A(1:c1)=[];wn(1:c1)=[];
           end
          break;
       elseif (sum(A(1:c1+1))*dw)<discard
          continue;
       end
    end
end

for c1=1:length(wn)
    if (sum(A(length(wn)-c1+1:length(wn)))*dw)>=discard
       break;
    else
       if (sum(A(length(wn)-c1:length(wn)))*dw)>=discard
           
           if c1<length(wn)
              A(length(wn)-c1+1:length(wn))=[];wn(length(wn)-c1+1:length(wn))=[];
           end
          break;
       elseif (sum(A(length(wn)-c1:length(wn)))*dw)<discard
          continue;
       end
    end
end


A=A/sum(A)/(wn(2)-wn(1));%normalize the spectra


