function [order,Qn,ds]=sort_qn(Qns)
%Qns are quentum numbers with random order
%This program sorts the Qns
Q=unique(Qns);
order=[];Qn=[];ds=[];
NN=length(Qns);
for c1=1:length(Q)
    order=[order,find(ones(1,NN)*Q(c1)==Qns)];
    Qn=[Qn,Q(c1)];
    ds=[ds,length(find(ones(1,NN)*Q(c1)==Qns))];
    
    
    
end












