

%Economical SVD:
function [U, S, V] = svd_D(T,D)
[m, n] = size(T);
if (D<m)&&(D<n)
    [U,S,V]=svd(T);
    
    U=U(:,1:D);
    S=S(1:D,1:D);
    V=V(:,1:D);
else
if m >=n,[U,S,V]=svd(T,0); else [V,S,U]=svd(T',0); end
end
V=V';