clc;clear;
L=3;%L sites, 2L spins
filenm = ['Semielliptic_N' num2str(L) '.mat' ];
load(filenm, '-mat');
%fork tensor product state
%site 1 corresponds to imourity
%o(L,up),o(L-1,up),o(L-2,up),...,o(1,up),O(1,down),o(2,down),...,o(L,down)
%���������˳���Ǵ��ҵ���.
%OBC
precision=10^-5;
d=2;D=30;


Vl=parameters{1,2};
epsilonl=parameters{1,3};
%Hamiltonian parameters
U_matrix=parameters{1,4};

mu_up=epsilonl;
mu_down=epsilonl;
tup_matrix=Vl;
tdown_matrix=Vl;

mu_up_imp=-U_matrix/2;
mu_down_imp=-U_matrix/2;

LL=L+1;%bath����impurityd size

sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);
n_up=(eye(2)-sz)/2;
n_down=(eye(2)-sz)/2;
sp=(sx+i*sy)/2;
sm=(sx-i*sy)/2;
%%%%%%%%%%%%%%

UA0=zeros(1,1,d,d);

%Hamiltonian
H_cell=cell(1,2*LL);
for c1=1:L
        new_mpo=cell(1,2*LL);
%spin up        
           %tc_{c1}^+c_{c2},c1<c2
              for cc=1:2*LL
                  if cc==c1
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(tup_matrix(L+1-c1)*sm,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  elseif (cc>c1)&&(cc<LL)
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sz,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;                   
                  elseif cc==LL
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sp,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  else
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(eye(2,2),[1,1,d,d]);
                      new_mpo{1,cc}=mpo;       
                  end
              end
            H_cell=[H_cell;new_mpo];
            %t'c_{c2}^+c_{c1}=-t'c_{c1}c_{c2}^+,c1<c2
              for cc=1:2*LL
                  if cc==c1
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(tup_matrix(L+1-c1)'*sp,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  elseif (cc>c1)&&(cc<LL)
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sz,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;                   
                  elseif cc==LL
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sm,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  else
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(eye(2,2),[1,1,d,d]);
                      new_mpo{1,cc}=mpo;       
                  end
              end
           H_cell=[H_cell;new_mpo];
end

for c1=1:L
        new_mpo=cell(1,2*LL);
%spin down        
           %tc_{c1}^+c_{c2},c1<c2
              for cc=1:2*LL
                  if cc==LL+1
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(tdown_matrix(c1)*sm,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  elseif (cc>LL+1)&&(cc<c1+LL+1)
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sz,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;                   
                  elseif cc==c1+LL+1
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sp,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  else
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(eye(2,2),[1,1,d,d]);
                      new_mpo{1,cc}=mpo;       
                  end
              end
            H_cell=[H_cell;new_mpo];
            %t'c_{c2}^+c_{c1}=-t'c_{c1}c_{c2}^+,c1<c2
              for cc=1:2*LL
                  if cc==LL+1
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(tdown_matrix(c1)'*sp,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  elseif (cc>LL+1)&&(cc<c1+LL+1)
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sz,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;                   
                  elseif cc==c1+LL+1
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(sm,[1,1,d,d]);
                      new_mpo{1,cc}=mpo;
                  else
                      mpo=UA0;
                      mpo(1,1,:,:)=reshape(eye(2,2),[1,1,d,d]);
                      new_mpo{1,cc}=mpo;       
                  end
              end
           H_cell=[H_cell;new_mpo];
end
H_cell(1,:)=[];


%�໥������
    new_mpo=cell(1,2*LL);
    for cc=1:2*LL
        if cc==LL
            mpo=UA0;
            mpo(1,1,:,:)=reshape(U_matrix*n_up,[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        elseif cc==LL+1
            mpo=UA0;
            mpo(1,1,:,:)=reshape(n_down,[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        else
            mpo=UA0;
            mpo(1,1,:,:)=reshape(eye(2),[1,1,d,d]);
            new_mpo{1,cc}=mpo;     
        end
    end
    H_cell=[H_cell;new_mpo];


for c1=1:L%��ѧ�ƶ��Ƕ��׵�
    new_mpo=cell(1,2*LL);
    for cc=1:2*LL
        if cc==c1
            mpo=UA0;
            mpo(1,1,:,:)=reshape(mu_up(L+1-c1)*n_up,[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        else
            mpo=UA0;
            mpo(1,1,:,:)=reshape(eye(2),[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        end
    end
    H_cell=[H_cell;new_mpo];
    
    new_mpo=cell(1,2*LL);
    for cc=1:2*LL
        if cc==LL+1+c1
            mpo=UA0;
            mpo(1,1,:,:)=reshape(mu_down(c1)*n_down,[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        else
            mpo=UA0;
            mpo(1,1,:,:)=reshape(eye(2),[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        end
    end
    H_cell=[H_cell;new_mpo];
end

%impurity��ѧ�ƶ��Ƕ��׵�
    new_mpo=cell(1,2*LL);
    for cc=1:2*LL
        if cc==LL
            mpo=UA0;
            mpo(1,1,:,:)=reshape(mu_up_imp*n_up,[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        else
            mpo=UA0;
            mpo(1,1,:,:)=reshape(eye(2),[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        end
    end
    H_cell=[H_cell;new_mpo];
    
    new_mpo=cell(1,2*LL);
    for cc=1:2*LL
        if cc==LL+1
            mpo=UA0;
            mpo(1,1,:,:)=reshape(mu_down_imp*n_down,[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        else
            mpo=UA0;
            mpo(1,1,:,:)=reshape(eye(2),[1,1,d,d]);
            new_mpo{1,cc}=mpo;
        end
    end
    H_cell=[H_cell;new_mpo];

     

load_filenm=['Semielliptic_N' num2str(L) '_D_20'];
 if exist([load_filenm '.mat'],'file')==2
    load Semielliptic_N19_D_20;
     mps0=grounds{1,2};
     
 else
     mps0=createrandommps(2*L,D,d);
     
 end


tic
hset=H_cell;
for c1=1:size(hset,1)
    for c2=1:size(hset,2)
        hset{c1,c2}=reshape(hset{c1,c2},[2,2]);
    end
end
% ground state energy
randn('state', 0)%���ó�ʼ״̬
tic
[E0, mps0] = minimizeE(hset, D, precision, []); 
toc

%%%%%%%%%
%evaluating energy of bulk
energy=0;
for c1=1:size(H_cell,1)  
    mpo=H_cell(c1,:);
    mps1=mpo_mps(mpo,mps0);
    energy=energy+overlap_1D(mps1,mps0)/overlap_1D(mps0,mps0);  
end




energy





grounds=cell(1,1);
grounds{1,1}=energy;grounds{1,2}=mps0;grounds{1,3}=D;grounds{1,4}=H_cell;
filenm=['Semielliptic_grounds_N' num2str(L) '_D_' num2str(D) ];
save([filenm],'grounds','parameters');

