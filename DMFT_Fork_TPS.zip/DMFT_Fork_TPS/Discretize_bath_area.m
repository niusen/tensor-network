function parameters=Discretize_bath_area(N,wn,A,U,t)
%when discretize bath, keep the length of integral region constant
A=A/sum(A)/(wn(2)-wn(1));%normalize the spectra
[A,wn]=Drop_weight(A,wn);%drop the zero weight spectral edges
dw=wn(2)-wn(1);




av_area=1/N;%average area
%from left to right
n_last=0;
for cn=1:(N-1)/2
for c1=n_last+1:length(wn)
    if (sum(A(n_last+1:c1))*dw)<av_area
       continue;
    elseif (sum(A(n_last+1:c1))*dw)>=av_area
       if abs((sum(A(n_last+1:c1))*dw)-av_area)>abs((sum(A(n_last+1:c1-1))*dw)-av_area)
           n_distri(cn)=max(c1-1,1);
       else
           n_distri(cn)=max(c1,1);
       end
       distri(cn)=n_distri(cn)-(n_last+1)+1;
       n_last=n_distri(cn);
       break;
    end
end
end

distri0=distri;
%from right to left
wn=wn(end:-1:1);A=A(end:-1:1);
n_last=0;
for cn=1:(N-1)/2
for c1=n_last+1:length(wn)
    if (sum(A(n_last+1:c1))*dw)<av_area
       continue;
    elseif (sum(A(n_last+1:c1))*dw)>=av_area
       if abs((sum(A(n_last+1:c1))*dw)-av_area)>abs((sum(A(n_last+1:c1-1))*dw)-av_area)
           n_distri(cn)=max(c1-1,1);
       else
           n_distri(cn)=max(c1,1);
       end
       distri(cn)=n_distri(cn)-(n_last+1)+1;
       n_last=n_distri(cn);
       break;
    end
end
end

%distri=[distri0,length(wn)-sum(distri)-1-(sum(distri)+1),fliplr(distri)];
distri=[distri0,length(wn)-sum(distri0)-sum(distri),fliplr(distri)];

wn=wn(end:-1:1);A=A(end:-1:1);


sum(distri)
length(wn)
total=length(wn)-sum(distri);%distribute the remaining
for c1=1:(total-mod(total,2))/2
       distri(c1)=distri(c1)+1;
       distri(N+1-c1)=distri(N+1-c1)+1;       
end

if mod(total,2)==1
    distri((total-mod(total,2))/2+1)=distri((total-mod(total,2))/2+1)+1;
end


    nl=1;
    nr=sum(distri(1:1));
    V_2(1)= sum(A(nl:nr))*dw;
    epsilon(1)=sum(wn(nl:nr).*A(nl:nr))*dw/V_2(1);
for c1=1:N
    nl=sum(distri(1:c1-1))+1;
    nr=sum(distri(1:c1));
    V_2(c1)= sum(A(nl:nr))*dw;
    epsilon(c1)=sum(wn(nl:nr).*A(nl:nr))*dw/V_2(c1); 
end


parameters=cell(1,4);
parameters{1,1}=N;
parameters{1,2}=sqrt(V_2);
parameters{1,3}=epsilon;
parameters{1,4}=U;



% eta=0.1;
% wn=linspace(-2,2,101);
% for c1=1:length(wn)
%     lamda(c1)=sum(V_2./(wn(c1)+i*eta-epsilon));
% end
% figure
% plot(wn,-imag(lamda)/pi,'b.');hold on;



