clc;clear;close all;
%o_up o_im_up o_im_down o_down 
%1    2       3         4
dt=0.05*i;
Time=15;

U_matrix=4;
epsilonl=0;
Vl=0.497226449570380;
mu_up=-U_matrix/2;
mu_down=-U_matrix/2;

id=eye(2);sx=[0,1;1,0];sy=[0,-1i;1i,0];sz=[1,0;0,-1];


c1=kron(kron(kron((sx+i*sy)/2,id),id),id);
cd1=kron(kron(kron((sx-i*sy)/2,id),id),id);
c2=kron(kron(kron(sz,(sx+i*sy)/2),id),id);
cd2=kron(kron(kron(sz,(sx-i*sy)/2),id),id);
c3=kron(kron(kron(sz,sz),(sx+i*sy)/2),id);
cd3=kron(kron(kron(sz,sz),(sx-i*sy)/2),id);
c4=kron(kron(kron(sz,sz),sz),(sx+i*sy)/2);
cd4=kron(kron(kron(sz,sz),sz),(sx-i*sy)/2);


H=U_matrix*cd2*c2*cd3*c3+mu_up*cd2*c2+mu_down*cd3*c3...
  +Vl*(cd1*c2+cd4*c3+cd2*c1+cd3*c4);


[ev eu]=eig(H);
v0=ev(:,1);



quasiup=cd2*v0;
vv=quasiup;energy=eu(1,1);
U=expm(-dt*H);
for time=0:round(Time/abs(dt))
    
    TT(time+1)=abs(dt*time);
    G(time+1)=-i*quasiup'*vv*exp(energy*i*abs(dt*time));
    vv=U*vv;
end
 
figure
plot(TT,real(G),'r');hold on;plot(TT,imag(G),'b');hold on;









