clc;clear;close all;
%impurity distribution:
%o(1),o(2),o(3),o(4),...,o(l-1),O(l),o(l+1),...,o(L)
%lԼ����L/2
%���������˳���Ǵ��ҵ��󣬼���L��1.
%OBC
L=1;
filenm = ['Semielliptic_N' num2str(L) '.mat' ];
load(filenm, '-mat');
dt=0.05*i;
Time=15;

Vl=parameters{1,2};
epsilonl=parameters{1,3};
%Hamiltonian parameters
U_matrix=zeros(1,L+1);
mu_up=zeros(1,L+1);
mu_down=zeros(1,L+1);
tup_matrix=zeros(L+1,L+1);
tdown_matrix=zeros(L+1,L+1);
U_matrix((L+1)/2)=parameters{1,4};
for c1=1:(L-1)/2
    mu_up(c1)=epsilonl(c1);
    mu_down(c1)=epsilonl(c1);
    tup_matrix(c1,(L+1)/2)=Vl(c1);
    tup_matrix((L+1)/2,c1)=Vl(c1);
    tdown_matrix(c1,(L+1)/2)=Vl(c1);
    tdown_matrix((L+1)/2,c1)=Vl(c1);
end
    mu_up((L+1)/2)=mu_up((L+1)/2)-U_matrix((L+1)/2)/2;
    mu_down((L+1)/2)=mu_down((L+1)/2)-U_matrix((L+1)/2)/2;


for c1=(L+1)/2:L
    mu_up(c1+1)=epsilonl(c1);
    mu_down(c1+1)=epsilonl(c1);
    tup_matrix(c1+1,(L+1)/2)=Vl(c1);
    tup_matrix((L+1)/2,c1+1)=Vl(c1);
    tdown_matrix(c1+1,(L+1)/2)=Vl(c1);
    tdown_matrix((L+1)/2,c1+1)=Vl(c1);
end
L=L+1;

sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);
n_up=(eye(2)-sz)/2;
n_down=(eye(2)-sz)/2;
sp=(sx+i*sy)/2;
sm=(sx-i*sy)/2;


%ע�⣺��ͬ������ģ�ͣ�c_i,c_{i+1}���Ƕ��׶��Ƿ�����
%ÿ��������ĸ�̬��vac, up, down, updown ��ŷֱ�Ϊ0, 1, 2, 3 
siz=2^(2*L);
state=zeros(siz,2*L);
 %base2dec��dec2base
 for c1=1:siz
    sstate=c1-1;
    shang=sstate;
    for c2=1:2*L
        yushu=mod(shang,2);
        state(c1,2*L+1-c2)=yushu;
        shang=(shang-yushu)/2;      
    end
end

for c1=1:siz
    for c2=1:2*L
        if state(c1,c2)==0
            occu(c1,c2)=0;
            Sz(c1,c2)=1;
        elseif state(c1,c2)==1
            occu(c1,c2)=1;
            Sz(c1,c2)=-1;
        end        
    end
end
 H=zeros(siz,siz);

 for c1=1:siz
     for c2=1:siz
         if c1==c2
             for c3=1:L
             H(c1,c2)=H(c1,c2)+U_matrix(c3)*(occu(c1,2*c3-1)*occu(c1,2*c3))...
                 +mu_up(c3)*(occu(c1,2*c3-1))...
                 +mu_down(c3)*(occu(c1,2*c3));
             end
         elseif sum(state(c1,1:2*L)==state(c2,1:2*L))==2*L-2
             position=find((state(c1,1:2*L)==state(c2,1:2*L))==zeros(1,2*L));%position�Ǵ������Ҵ�С������
             a1=position(1);a2=position(2);%a1<a2
           if mod(a1-a2,2)==0
             if (Sz(c1,a1)<Sz(c2,a1))%t*c_{a1}^+c_{a2}
                if mod(a1,2)==1%spin up
                a0=Sz(c2,a1+1);
                for cin=a1+2:a2-1
                    a0=a0*Sz(c2,cin);
                end
                H(c1,c2)=H(c1,c2)+tup_matrix((a1+1)/2,(a2+1)/2)*sm(state(c1,a1)+1,state(c2,a1)+1)*sp(state(c1,a2)+1,state(c2,a2)+1)*a0;
                elseif mod(a1,2)==0%spin down
                a0=Sz(c2,a1+1);
                for cin=a1+2:a2-1
                    a0=a0*Sz(c2,cin);
                end
                H(c1,c2)=H(c1,c2)+tdown_matrix(a1/2,a2/2)*sm(state(c1,a1)+1,state(c2,a1)+1)*sp(state(c1,a2)+1,state(c2,a2)+1)*a0;
                end
             elseif (Sz(c1,a1)>Sz(c2,a1))%t*c_{a2}^+c_{a1}=-t*c_{a1}c_{a2}^+
                if mod(a1,2)==1%spin up
                a0=Sz(c2,a1+1);
                for cin=a1+2:a2-1
                    a0=a0*Sz(c2,cin);
                end
                H(c1,c2)=H(c1,c2)+tup_matrix((a1+1)/2,(a2+1)/2)*sp(state(c1,a1)+1,state(c2,a1)+1)*sm(state(c1,a2)+1,state(c2,a2)+1)*a0;
                elseif mod(a1,2)==0%spin down
                a0=Sz(c2,a1+1);
                for cin=a1+2:a2-1
                    a0=a0*Sz(c2,cin);
                end
                H(c1,c2)=H(c1,c2)+tdown_matrix(a1/2,a2/2)*sp(state(c1,a1)+1,state(c2,a1)+1)*sm(state(c1,a2)+1,state(c2,a2)+1)*a0;
                end
             end    
             
           end
        end
     end
 end
 
 H=H/2+H'/2;
%options.disp = 0;
%[ev, EE] = eigs(H, 2, 'SA', options); 
[ev,EE]=eig(H);
 
 for c1=1:size(H,1)
     [aa,bb]=max(abs(ev(:,c1)));
     particle(c1)=sum(occu(bb,:));
 end
 
 EE(1,1)
 EE(2,2)
 
 v1=ev(:,1);
 
 
 
quasi_up=zeros(siz,siz);
quasi_down=zeros(siz,siz);
  for c1=1:siz
     for c2=1:siz
         if sum(state(c1,1:2*L)==state(c2,1:2*L))==2*L-1
             position=find((state(c1,1:2*L)==state(c2,1:2*L))==zeros(1,2*L));%position�Ǵ������Ҵ�С������
             a1=position(1);
           if a1==(2*(L/2)-1)%up quasi-particle
                a0=1;
                for cin=1:a1-1
                    a0=a0*Sz(c2,cin);
                end
              quasi_up(c1,c2)=a0*sm(state(c1,a1)+1,state(c2,a1)+1);
             elseif a1==(2*(L/2))%down quasi-particle
                 a0=1;
                for cin=1:a1-1
                    a0=a0*Sz(c2,cin);
                end
              quasi_down(c1,c2)=a0*sm(state(c1,a1)+1,state(c2,a1)+1);         
           end
        end
     end
  end
 


quasiup=quasi_up*v1;
vv=quasiup;energy=EE(1,1);
U=expm(-dt*H);
for time=0:round(Time/abs(dt))
    
    TT(time+1)=abs(dt*time);
    G(time+1)=-i*quasiup'*vv*exp(energy*i*abs(dt*time));
    vv=U*vv;
end
 
figure
plot(TT,real(G),'r');hold on;plot(TT,imag(G),'b');hold on;

