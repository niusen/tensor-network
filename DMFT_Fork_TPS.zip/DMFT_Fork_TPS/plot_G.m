close all;
TT=Green{1,1};
G=Green{1,2};
plot(TT,real(G),'r');hold on;
plot(TT,imag(G),'b');hold on;