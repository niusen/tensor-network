clc;clear;close all;
N=39;
v=1;I=linspace(-2*v,2*v,N+1);
M=100;
U=4*v;
eta=0.1;

for c1=1:N
    w=linspace(I(c1),I(c1+1),M);
    V_2(c1)= sum((1/2/v/pi)*sqrt(4-(w/v).^2))*(w(2)-w(1));
    epsilon(c1)=sum((1/2/v/pi)*w.*sqrt(4-(w/v).^2))*(w(2)-w(1))/V_2(c1); 
end
plot(sqrt(V_2)*2,'.');hold on;
figure
plot(epsilon,'.');hold on;
parameters=cell(1,3);
parameters{1,1}=N;
parameters{1,2}=sqrt(V_2);
parameters{1,3}=epsilon;
parameters{1,4}=U;
filenm=['Semielliptic_N' num2str(N) '.mat' ];
save( filenm,'-mat');

wn=linspace(-2,2,101);
for c1=1:length(wn)
    lamda0(c1)=sqrt(4-(wn(c1)/v).^2)/2/pi/v;
    lamda(c1)=sum(V_2./(wn(c1)+i*eta-epsilon));
end
figure
plot(wn,lamda0,'r.');hold on;
plot(wn,-imag(lamda)/pi,'b.');hold on;

