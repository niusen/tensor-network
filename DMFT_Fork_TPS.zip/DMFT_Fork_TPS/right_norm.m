function mps=right_norm(mps)
%from left to right
N=size(mps,2);
for c1=1:N-1
M=mps{1,c1};[D1,D2,d]=size(M); 
M=permute(M,[3,1,2]);M=reshape(M,[d*D1,D2]); 
[U,S,B]=svd2(M);DB=size(S, 1);
U=reshape(U,[d,D1,DB]); U=permute(U,[2,3,1]); 
mps{1,c1}=U;
SB=S*B;
mps{1,c1+1}=contracttensors(SB,2,2,mps{1,c1+1},3,1); 
end
%normalize
A=mps{1,N};
[D1,D2,d]=size(A);
A=reshape(A,[D1*d,1]);
ov=A'*A;
mps{1,N}=mps{1,N}/sqrt(ov);






