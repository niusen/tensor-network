function [G,TT]=fork_tensor_G(L,D0,tm,t_sign,precision)

filenm=['Semielliptic_grounds_N' num2str(L) '_D_' num2str(D0) ];
load([filenm]);
mps0=grounds{1,2};energy=grounds{1,1};
%o_up3 o_up2 o_up1 o_im_up o_im_down o_down1 o_down2 o_down3 
%1     2     3       4         5       6     7       8
%impurity�������м�
%OBC

d=2;
Time=15;

sx=[0,1;1,0];sy=[0,-1i;1i,0];sz=[1,0;0,-1];id=eye(2);
occu=(eye(2)-sz)/2;

sp=(sx+i*sy)/2;
sm=(sx-i*sy)/2;

Vl=parameters{1,2};
epsilonl=parameters{1,3};
%Hamiltonian parameters
U_matrix=parameters{1,4};

mu_up=epsilonl;
mu_down=epsilonl;
tup_matrix=Vl;
tdown_matrix=Vl;

mu_up_imp=-U_matrix/2;
mu_down_imp=-U_matrix/2;

LL=L+1;%bath����impurityd size



%�������
quasi_up=cell(1,2*(L+1));
quasi_upp=cell(1,2*(L+1));
quasi_down=cell(1,2*(L+1));
quasi_downp=cell(1,2*(L+1));
for c1=1:size(quasi_up,2)
    if c1==LL
        quasi_up{1,c1}=reshape(sm,[1,1,2,2]);
    elseif c1<LL
        quasi_up{1,c1}=reshape(sz,[1,1,2,2]);
    elseif c1>LL
        quasi_up{1,c1}=reshape(id,[1,1,2,2]); 
    end

    if c1==LL
        quasi_upp{1,c1}=reshape(sm',[1,1,2,2]);
    elseif c1<LL
        quasi_upp{1,c1}=reshape(sz',[1,1,2,2]);
    elseif c1>LL
        quasi_upp{1,c1}=reshape(id,[1,1,2,2]); 
    end
    
    if c1==LL+1
        quasi_down{1,c1}=reshape(sm,[1,1,2,2]);
    elseif c1<LL+1
        quasi_down{1,c1}=reshape(sz,[1,1,2,2]);
    elseif c1>LL+1
        quasi_down{1,c1}=reshape(id,[1,1,2,2]); 
    end
    
    if c1==LL+1
        quasi_downp{1,c1}=reshape(sm',[1,1,2,2]);
    elseif c1<LL+1
        quasi_downp{1,c1}=reshape(sz',[1,1,2,2]);
    elseif c1>LL+1
        quasi_downp{1,c1}=reshape(id,[1,1,2,2]); 
    end
end



%%%%%%%%%%%%%%


%%%%%%%
mps0=left_norm(mps0);
if t_sign==1
mps_quasiup=mpo_mps(quasi_up,mps0);%quasi-particle
mps_quasiup0=mps_quasiup;
elseif t_sign==-1
mps_quasiup=mpo_mps(quasi_upp,mps0);%quasi-particle
mps_quasiup0=mps_quasiup;
end





%time evolve

dt_last=[];

for time=1:length(tm)
    
    time
dt=tm(time);   
if isempty(dt_last)==1    
mpos=Fork_tensor_evolve_mpo(L,abs(dt),parameters);
mpo_mu=mpos{1,1};
U_mpo=mpos{1,2};
hop_up_first_mpo=mpos{1,3};
hop_up_second_mpo=mpos{1,4};
hop_down_first_mpo=mpos{1,5};
hop_down_second_mpo=mpos{1,6};  
dt_last=dt;
else
    if dt==dt_last
        
    else
mpos=Fork_tensor_evolve_mpo(L,abs(dt),parameters);
mpo_mu=mpos{1,1};
U_mpo=mpos{1,2};
hop_up_first_mpo=mpos{1,3};
hop_up_second_mpo=mpos{1,4};
hop_down_first_mpo=mpos{1,5};
hop_down_second_mpo=mpos{1,6};  
dt_last=dt;
    end
end
    
    
    
%chemical potential evolution
for cs=1:2*LL
    mps_quasiup{1,cs}=contracttensors(mpo_mu{cs,1},2,2,mps_quasiup{1,cs},3,3);
    mps_quasiup{1,cs}=permute(mps_quasiup{1,cs},[2,3,1]);
end


%interaction evolution
%mix-canonical form at impurity site
mps_quasiup=left_norm_position(mps_quasiup,2*LL,LL+1);
mps_quasiup=right_norm_position(mps_quasiup,1,LL);
[mps_quasiup{1,LL},mps_quasiup{1,LL+1}]=twosite_precision(mps_quasiup{1,LL},mps_quasiup{1,LL+1},U_mpo{1,1},U_mpo{1,2},precision);
%%%%%%

%spin up, impurity mu, bath mu and hopping evolution
%mix-canonical form at impurity site
mps_quasiup=left_norm_position(mps_quasiup,LL+1,LL+1);
for c1=1:L%bath site, first evolution, then swap site
    cs=L+1-c1;%position of bath
    [mps_quasiup{1,cs},mps_quasiup{1,cs+1}]=twosite_precision(mps_quasiup{1,cs},mps_quasiup{1,cs+1},hop_up_first_mpo{c1,1},hop_up_first_mpo{c1,2},precision);
    mps_quasiup=left_norm_position(mps_quasiup,cs+1,cs+1);
end
%%%%%%

%spin up back
for c1=1:L%bath site, first evolution, then swap site
    cs=c1;%position of bath
    [mps_quasiup{1,cs},mps_quasiup{1,cs+1}]=twosite_precision(mps_quasiup{1,cs},mps_quasiup{1,cs+1},hop_up_second_mpo{c1,1},hop_up_second_mpo{c1,2},precision);
    mps_quasiup=right_norm_position(mps_quasiup,cs,cs);
end
%%%%%%

%spin down, impurity mu, bath mu and hopping evolution
%mix-canonical form at impurity site
mps_quasiup=right_norm_position(mps_quasiup,LL,LL);
for c1=1:L%bath site, first evolution, then swap site
    cs=c1;%position of bath
    [mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1}]=twosite_precision(mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1},hop_down_first_mpo{c1,1},hop_down_first_mpo{c1,2},precision);
    mps_quasiup=right_norm_position(mps_quasiup,LL+cs,LL+cs);
end
%%%%%

%spin down back
for c1=1:L%bath site, first evolution, then swap site
    cs=L+1-c1;%position of bath
    [mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1}]=twosite_precision(mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1},hop_down_second_mpo{c1,1},hop_down_second_mpo{c1,2},precision);
    mps_quasiup=left_norm_position(mps_quasiup,LL+cs+1,LL+cs+1);
end
%%%%

%interaction evolution
%mix-canonical form at impurity site
mps_quasiup=left_norm_position(mps_quasiup,LL+1,LL+1);
[mps_quasiup{1,LL},mps_quasiup{1,LL+1}]=twosite_precision(mps_quasiup{1,LL},mps_quasiup{1,LL+1},U_mpo{1,1},U_mpo{1,2},precision);



%chemical potential evolution
for cs=1:2*LL
    mps_quasiup{1,cs}=contracttensors(mpo_mu{cs,1},2,2,mps_quasiup{1,cs},3,3);
    mps_quasiup{1,cs}=permute(mps_quasiup{1,cs},[2,3,1]);
end


    TT(time)=sum(tm(1:time));
    G(time)=-i*overlap_1D(mps_quasiup0,mps_quasiup)*exp(energy*i*abs(sum(tm(1:time))));
end


Green=cell(1,2);
Green{1,1}=TT;
Green{1,2}=G;
Green{1,3}=mps_quasiup;
filenm=['G_fork_N' num2str(L) '_precision_' num2str(-log10(precision)) '_2nd_trotter' '.mat'];
save([filenm],'Green');

