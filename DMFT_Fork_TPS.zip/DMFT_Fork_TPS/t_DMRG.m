function mps=t_DMRG(mps,mpo,D,odd_even)
%perform once trotter over the whole latice (even or odd)
%odd, (1,2),(3,4),...
%even,(2,3),(4,5),...
N=size(mps,2);


if odd_even=='o'
    
mps=left_norm(mps);

for c1=1:(N-mod(N,2))/2
[mps{1,2*c1-1}, mps{1,2*c1}] = T_dmrg(mps{1,2*c1-1}, mps{1,2*c1}, mpo{c1,1}, mpo{c1,2}, D);
if 2*c1<N
mps=move_twosite(mps,2*c1);
end
end




elseif odd_even=='e'
    
mps=left_norm(mps);

for c1=1:(N+mod(N,2))/2-1
mps=move_twosite(mps,1);
[mps{1,2*c1}, mps{1,2*c1+1}] = T_dmrg(mps{1,2*c1}, mps{1,2*c1+1}, mpo{c1,1}, mpo{c1,2}, D);
if 2*c1+1<N
mps=move_twosite(mps,2*c1+1);
end
end
mps=left_norm(mps);
end


end





function [mpsA, mpsB] = T_dmrg(mpsA, mpsB, mpoX, mpoY, D)

%mpo:%
%mpo1 = reshape(U, [2, 2, eta]); 
%mpo2 = reshape(V, [eta, 2, 2]); V=permute(V,[2 3 1]); 

    A=contracttensors(mpsA,3,3,mpoX,3,2);sizeA=size(A);
    B=contracttensors(mpsB,3,3,mpoY,3,2);sizeB=size(B);
    AB=contracttensors(A,4,[2 4],B,4,[1 4]);
    AB=permute(AB,[1 2 4 3]);AB=reshape(AB,[sizeA(1)*sizeA(3),sizeB(3)*sizeB(2)]);
    [u s v]=svd_D(AB,D);
    [dl dr]=size(u);
    u=reshape(u,[dl/sizeA(3),sizeA(3),dr]);
    u=permute(u,[1 3 2]);
    mpsA=u;
   [dl dr]=size(v);
   v=reshape(v,[dl,sizeB(3),dr/sizeB(3)]);v=permute(v,[1 3 2]);

    
    mpsB=contracttensors(s,2,2,v,3,1);
end
