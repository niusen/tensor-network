function mps=t_DMRG_precision(mps,mpo,precision,odd_even)
%perform once trotter over the whole latice (even or odd)
%odd, (1,2),(3,4),...
%even,(2,3),(4,5),...
N=size(mps,2);


if odd_even=='o'
    
mps=left_norm(mps);

for c1=1:(N-mod(N,2))/2
[mps{1,2*c1-1}, mps{1,2*c1}] = twosite_precision(mps{1,2*c1-1}, mps{1,2*c1}, mpo{c1,1}, mpo{c1,2}, precision);
if 2*c1<N
mps=move_twosite(mps,2*c1);
end
end




elseif odd_even=='e'
    
mps=left_norm(mps);

for c1=1:(N+mod(N,2))/2-1
mps=move_twosite(mps,1);
[mps{1,2*c1}, mps{1,2*c1+1}] = twosite_precision(mps{1,2*c1}, mps{1,2*c1+1}, mpo{c1,1}, mpo{c1,2}, precision);
if 2*c1+1<N
mps=move_twosite(mps,2*c1+1);
end
end
mps=left_norm(mps);
end


end






