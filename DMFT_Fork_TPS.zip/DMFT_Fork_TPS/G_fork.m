clc;clear;close all;
L=39;%L sites, 2L spins
D0=50;
precision=10^-7;
symmetric=0;
t_max=15;
dt=0.05;
tm=dt*ones(1,round(t_max/dt));tm(1)=tm(1)-dt/2;
t_sign=1;
tm1=tm;
[G1,TT1]=fork_tensor_G(L,D0,tm1,t_sign,precision);
if symmetric==0
tm2=-tm1;
[G2,TT2]=fork_tensor_G(L,D0,tm2,-t_sign,precision);
else
TT2=-TT1;
G2=G1;
end

save test;
load test;

G=conj(G2/(-i))*(-i)+G1;%retarded Green function, not time ordered
nw=10000;w_max=6;
for c1=1:(2*nw+1)
wn(c1)=(c1-1)/nw*w_max-w_max;
end
for c1=1:(2*nw+1)
Gw(c1)=sum(exp(i*wn(c1)*TT1).*G)*(wn(2)-wn(1));
end
A=-imag(Gw);A=A/sum(A)/(wn(2)-wn(1))*pi;
plot(wn,A)


%question: in this way, the inverse fourier transformation is not G(t),
%i.e., no one to one correspondence


