function y=test_right_norm(A)
[d1 d2 d3]=size(A);
A=reshape(A,[d1,d2*d3]);
y=A*A';