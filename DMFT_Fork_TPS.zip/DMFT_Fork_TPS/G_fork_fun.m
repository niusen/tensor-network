function [G,TT1]=G_fork_fun(L,D0,precision,symmetric,t_max,dt)

tm=dt*ones(1,round(t_max/dt));tm(1)=tm(1)-dt/2;
t_sign=1;
tm1=tm;
[G1,TT1]=fork_tensor_G(L,D0,tm1,t_sign,precision);
if symmetric==0
tm2=-tm1;
[G2,TT2]=fork_tensor_G(L,D0,tm2,-t_sign,precision);
else
TT2=-TT1;
G2=G1;
end



G=conj(G2/(-i))*(-i)+G1;%retarded Green function, not time ordered


