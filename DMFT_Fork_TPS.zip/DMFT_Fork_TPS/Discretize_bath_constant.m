function parameters=Discretize_bath_constant(N,wn,A,U,t)
%when discretize bath, keep the length of integral region constant
%N is odd number
A=A/sum(A)/(wn(2)-wn(1));%normalize the spectra
[A,wn]=Drop_weight(A,wn);%drop the zero weight spectral edges

lw=length(wn);
l_region=(lw-mod(lw,N))/N;
dw=wn(2)-wn(1);
distri=l_region*ones(1,N);
total=mod(lw,N);


for c1=1:(total-mod(total,2))/2
       distri(c1)=distri(c1)+1;
       distri(N+1-c1)=distri(N+1-c1)+1;       
end

if mod(total,2)==1
    distri((total-mod(total,2))/2+1)=distri((total-mod(total,2))/2+1)+1;
end


    nl=1;
    nr=sum(distri(1:1));
    V_2(1)= sum(A(nl:nr))*dw;
    epsilon(1)=sum(wn(nl:nr).*A(nl:nr))*dw/V_2(1);
for c1=1:N
    nl=sum(distri(1:c1-1))+1;
    nr=sum(distri(1:c1));
    V_2(c1)= sum(A(nl:nr))*dw;
    epsilon(c1)=sum(wn(nl:nr).*A(nl:nr))*dw/V_2(c1); 
end


parameters=cell(1,4);
parameters{1,1}=N;
parameters{1,2}=sqrt(V_2);
parameters{1,3}=epsilon;
parameters{1,4}=U;


% eta=0.1;
% wn=linspace(-2,2,101);
% for c1=1:length(wn)
%     lamda(c1)=sum(V_2./(wn(c1)+i*eta-epsilon));
% end
% figure
% plot(wn,-imag(lamda)/pi,'b.');hold on;
