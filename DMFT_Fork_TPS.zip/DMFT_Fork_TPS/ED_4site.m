clc;clear;close all;
%o_up3 o_up2 o_up1 o_im_up o_im_down o_down1 o_down2 o_down3 
%1     2     3       4         5       6     7       8
dt=0.05*i;
Time=15;

U_matrix=4;
epsilonl=[-1.214863211045535  -0.000000000000000   1.214863211045534];
Vl=[0.466989827848809   0.558739253785929   0.466989827848809];
mu_up=-U_matrix/2;
mu_down=-U_matrix/2;

id=eye(2);sx=[0,1;1,0];sy=[0,-1i;1i,0];sz=[1,0;0,-1];


c1=kron(kron(kron(kron(kron(kron(kron((sx+i*sy)/2,id),id),id),id),id),id),id);
cd1=kron(kron(kron(kron(kron(kron(kron((sx-i*sy)/2,id),id),id),id),id),id),id);
c2=kron(kron(kron(kron(kron(kron(kron(sz,(sx+i*sy)/2),id),id),id),id),id),id);
cd2=kron(kron(kron(kron(kron(kron(kron(sz,(sx-i*sy)/2),id),id),id),id),id),id);
c3=kron(kron(kron(kron(kron(kron(kron(sz,sz),(sx+i*sy)/2),id),id),id),id),id);
cd3=kron(kron(kron(kron(kron(kron(kron(sz,sz),(sx-i*sy)/2),id),id),id),id),id);
c4=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),(sx+i*sy)/2),id),id),id),id);
cd4=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),(sx-i*sy)/2),id),id),id),id);
c5=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),(sx+i*sy)/2),id),id),id);
cd5=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),(sx-i*sy)/2),id),id),id);
c6=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),(sx+i*sy)/2),id),id);
cd6=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),(sx-i*sy)/2),id),id);
c7=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),sz),(sx+i*sy)/2),id);
cd7=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),sz),(sx-i*sy)/2),id);
c8=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),sz),sz),(sx+i*sy)/2);
cd8=kron(kron(kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),sz),sz),(sx-i*sy)/2);







H=U_matrix*cd4*c4*cd5*c5+mu_up*cd4*c4+mu_down*cd5*c5...
  +epsilonl(1)*cd3*c3+epsilonl(1)*cd6*c6+epsilonl(2)*cd2*c2+epsilonl(2)*cd7*c7...
  +epsilonl(3)*cd1*c1+epsilonl(3)*cd8*c8...
  +Vl(1)*(cd3*c4+cd6*c5+cd4*c3+cd5*c6)+Vl(2)*(cd2*c4+cd7*c5+cd4*c2+cd5*c7)...
  +Vl(3)*(cd1*c4+cd8*c5+cd4*c1+cd5*c8);


[ev eu]=eig(H);
v0=ev(:,1);



quasiup=cd4*v0;
vv=quasiup;energy=eu(1,1);
U=expm(-dt*H);
for time=0:round(Time/abs(dt))
    
    TT(time+1)=abs(dt*time);
    G(time+1)=-i*quasiup'*vv*exp(energy*i*abs(dt*time));
    vv=U*vv;
end
 
figure
plot(TT,real(G),'r');hold on;plot(TT,imag(G),'b');hold on;









