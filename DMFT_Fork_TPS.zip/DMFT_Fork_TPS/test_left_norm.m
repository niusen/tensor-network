function y=test_left_norm(A)
[d1 d2 d3]=size(A);
A=permute(A,[1,3,2]);
A=reshape(A,[d1*d3,d2]);
y=A'*A;