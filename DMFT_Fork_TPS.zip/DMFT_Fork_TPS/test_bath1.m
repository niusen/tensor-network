clc;clear;close all;
N=39;

U=4;
eta=0.1;



wn=linspace(-4,4,100001);
for c1=1:length(wn)
    if abs(wn(c1))<=2
    lamda0(c1)=sqrt(4-(wn(c1)).^2)/2/pi;
    else 
        lamda0(c1)=0;
    end
   
end


figure
parameters=Discretize_bath_constant(N,wn,lamda0,4,1);
vl=parameters{1,2};
epsilon=parameters{1,3};
plot(wn,lamda0,'.');
figure
plot(vl,'.');
figure
plot(epsilon,'.')


wwn=linspace(-2,2,101);
for c1=1:length(wwn)
    lamda(c1)=sum(vl.^2./(wwn(c1)+i*eta-epsilon));
end
figure
plot(wwn,-imag(lamda)/pi,'b.');hold on;




figure
parameters=Discretize_bath_area(N,wn,lamda0,4,1);
vl=parameters{1,2};
epsilon=parameters{1,3};
plot(vl,'.');
figure
plot(epsilon,'.')

wwn=linspace(-2,2,101);
for c1=1:length(wwn)
    lamda(c1)=sum(vl.^2./(wwn(c1)+i*eta-epsilon));
end
figure
plot(wwn,-imag(lamda)/pi,'b.');hold on;

