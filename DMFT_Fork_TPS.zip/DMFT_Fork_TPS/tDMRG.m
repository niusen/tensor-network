clc;clear;close all;
N=30;%������iterativeѹ����Ҫ���ಽ�衣�ȷ�˵��iterativeѹ��t=3��������Ҫt������ܴﵽ��ͬ����
D=6;
precision = 1e-5;
dt = 0.01;
d=2;

sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);


% time evolution operator
h = kron(sx, sx) + kron(sy, sy) + kron(sz, sz);
%site 1,2 �ϵľ���ָ��Ϊ(sigma_{1}sigma_{2},sigma_{1}'sigma_{2}')
w=expm(-dt*h);
w = reshape(w, [2, 2, 2, 2]); w = permute(w, [1, 3, 2, 4]);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
w = reshape(w, [4, 4]);%ָ��Ϊ(sigma_{1}sigma_{1}',sigma_{2}sigma_{2}')
[U, S, V] = svd2(w); eta = size(S, 1);
U=U*sqrt(S); V=sqrt(S)*V;
U = reshape(U, [2, 2, eta]); 
V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 



% time evolution
load mps30.mat;
%mps = createrandommps(N, D, d);
%mps = prepare(mps);
mpo_odd=cell(1,(N-mod(N,2))/2);
mpo_even=cell(1,(N+mod(N,2))/2-1);

for c1=1:size(mpo_odd,2)
    mpo_odd{c1,1}=U;
    mpo_odd{c1,2}=V;
end
for c1=1:size(mpo_even,2)
    mpo_even{c1,1}=U;
    mpo_even{c1,2}=V;
end



for step = 1:round(5/dt)
    mps=t_DMRG(mps,mpo_odd,D,'o');
    mps=t_DMRG(mps,mpo_even,D,'e');
    
end

M=3*(N-1);
hset = cell(M, N);
sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2); 
for m=1:M,for j=1:N,hset{m,j}=id; end; end
for j=1:(N-1)
hset{3*(j-1)+1,j}=sx; hset{3*(j-1)+1,j+1}=sx; 
hset{3*(j-1)+2,j}=sy; hset{3*(j-1)+2,j+1}=sy;
hset{3*(j-1)+3,j}=sz; hset{3*(j-1)+3,j+1}=sz;
end
expectationvalue(mps, hset)

jflipped = 5;
% magnetization in z-direction
oset = cell(1, N);
sx = [0, 1;1, 0]; sy = [0, -1i;1i, 0]; sz = [1, 0;0, -1]; id = eye(2);
for j = 1:N, oset{1, j} = id; end;
oset{1, jflipped} = sz;

mz = expectationvalue(mps, oset)