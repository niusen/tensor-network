clc;clear;close all;
load test;

N=39;

U=4;
eta=0.1;


G=conj(G2/(-i))*(-i)+G1;
wn=linspace(-6,6,100001);
for c1=1:length(wn)
lamda0(c1)=-imag(sum(exp(i*wn(c1)*TT1).*G));
   
end
figure
plot(wn,lamda0);

%constant discretize
figure
parameters=Discretize_bath_constant(N,wn,lamda0,4,1);
vl=parameters{1,2};
epsilon=parameters{1,3};
plot(wn,lamda0,'.');
figure
plot(vl,'.');
figure
plot(epsilon,'.')

wwn=linspace(-6,6,101);
for c1=1:length(wwn)
    lamda(c1)=sum(vl.^2./(wwn(c1)+i*eta-epsilon));
end
figure
plot(wwn,-imag(lamda)/pi,'b.');hold on;
vl


%equal area discretize
figure
parameters=Discretize_bath_area(N,wn,lamda0,4,1);
vl=parameters{1,2};
epsilon=parameters{1,3};
plot(vl,'.');
figure
plot(epsilon,'.')


wwn=linspace(-6,6,101);
for c1=1:length(wwn)
    lamda(c1)=sum(vl.^2./(wwn(c1)+i*eta-epsilon));
end
figure
plot(wwn,-imag(lamda)/pi,'b.');hold on;