clc;clear;close all;
%o_up2 o_up1 o_im_up o_im_down o_down1 o_down2 
%1     2     3       4         5       6
dt=0.05*i;
Time=15;

U_matrix=-3;
epsilonl=[-0.842945530647845,0.942945530647845];
Vl=[0.498996518432603,0.598996518432603];
mu_up=-U_matrix/2;
mu_down=-U_matrix/2;

id=eye(2);sx=[0,1;1,0];sy=[0,-1i;1i,0];sz=[1,0;0,-1];


c1=kron(kron(kron(kron(kron((sx+i*sy)/2,id),id),id),id),id);
cd1=kron(kron(kron(kron(kron((sx-i*sy)/2,id),id),id),id),id);
c2=kron(kron(kron(kron(kron(sz,(sx+i*sy)/2),id),id),id),id);
cd2=kron(kron(kron(kron(kron(sz,(sx-i*sy)/2),id),id),id),id);
c3=kron(kron(kron(kron(kron(sz,sz),(sx+i*sy)/2),id),id),id);
cd3=kron(kron(kron(kron(kron(sz,sz),(sx-i*sy)/2),id),id),id);
c4=kron(kron(kron(kron(kron(sz,sz),sz),(sx+i*sy)/2),id),id);
cd4=kron(kron(kron(kron(kron(sz,sz),sz),(sx-i*sy)/2),id),id);
c5=kron(kron(kron(kron(kron(sz,sz),sz),sz),(sx+i*sy)/2),id);
cd5=kron(kron(kron(kron(kron(sz,sz),sz),sz),(sx-i*sy)/2),id);
c6=kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),(sx+i*sy)/2);
cd6=kron(kron(kron(kron(kron(sz,sz),sz),sz),sz),(sx-i*sy)/2);








H=U_matrix*cd3*c3*cd4*c4+mu_up*cd3*c3+mu_down*cd4*c4...
  +epsilonl(1)*cd2*c2+epsilonl(1)*cd5*c5+epsilonl(2)*cd1*c1+epsilonl(2)*cd6*c6...
  +Vl(1)*(cd2*c3+cd5*c4+cd3*c2+cd4*c5)+Vl(2)*(cd1*c3+cd6*c4+cd3*c1+cd4*c6);


[ev eu]=eig(H);
v0=ev(:,1);



quasiup=cd3*v0;
vv=quasiup;energy=eu(1,1);
U=expm(-dt*H);
for time=0:round(Time/abs(dt))
    
    TT(time+1)=abs(dt*time);
    G(time+1)=-i*quasiup'*vv*exp(energy*i*abs(dt*time));
    vv=U*vv;
end
 
figure
plot(TT,real(G),'r');hold on;plot(TT,imag(G),'b');hold on;









