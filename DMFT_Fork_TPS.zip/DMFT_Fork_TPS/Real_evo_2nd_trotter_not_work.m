clc;clear;close all;
L=1;%L sites, 2L spins
D0=30;D=20;
filenm=['Semielliptic_grounds_N' num2str(L) '_D_' num2str(D0) ];
load([filenm]);
mps0=grounds{1,2};energy=grounds{1,1};
filenm = ['Semielliptic_N' num2str(L) '.mat' ];
load(filenm, '-mat');
%o_up3 o_up2 o_up1 o_im_up o_im_down o_down1 o_down2 o_down3 
%1     2     3       4         5       6     7       8
%impurity�������м�
%OBC
precision=10^-7;
d=2;
dt=0.05;Time=15;

sx=[0,1;1,0];sy=[0,-1i;1i,0];sz=[1,0;0,-1];id=eye(2);
occu=(eye(2)-sz)/2;

sp=(sx+i*sy)/2;
sm=(sx-i*sy)/2;

Vl=parameters{1,2};
epsilonl=parameters{1,3};
%Hamiltonian parameters
U_matrix=parameters{1,4};

mu_up=epsilonl;
mu_down=epsilonl;
tup_matrix=Vl;
tdown_matrix=Vl;

mu_up_imp=-U_matrix/2;
mu_down_imp=-U_matrix/2;

LL=L+1;%bath����impurityd size

swap=zeros(2,2,2,2);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
swap(1,1,1,1)=1;
swap(1,2,2,1)=1;
swap(2,1,1,2)=1;
swap(2,2,2,2)=-1;

%�������
quasi_up=cell(1,2*(L+1));
quasi_down=cell(1,2*(L+1));
for c1=1:size(quasi_up,2)
    if c1==LL
        quasi_up{1,c1}=reshape(sm,[1,1,2,2]);
    elseif c1<LL
        quasi_up{1,c1}=reshape(sz,[1,1,2,2]);
    elseif c1>LL
        quasi_up{1,c1}=reshape(id,[1,1,2,2]); 
    end
    
    if c1==LL+1
        quasi_down{1,c1}=reshape(sm,[1,1,2,2]);
    elseif c1<LL+1
        quasi_down{1,c1}=reshape(sz,[1,1,2,2]);
    elseif c1>LL+1
        quasi_down{1,c1}=reshape(id,[1,1,2,2]); 
    end
end

%%%%%%%%%%%%%%

exp_H_Re=cell(1,2*L);
%hoppings
UA0=zeros(1,1,d,d);
UA1=zeros(1,2,d,d);
UA2=zeros(2,2,d,d);
UA3=zeros(2,1,d,d);
%%%%%%%
mps0=left_norm(mps0);
mps_quasiup=mpo_mps(quasi_up,mps0);%quasi-particle
mps_quasiup0=mps_quasiup;

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%evolution operator
%interaction evolution
%mix-canonical form at impurity site

h=U_matrix*kron(occu,occu);
w=expm(-i*dt/2*h);
w=reshape(w, [2, 2, 2, 2]); w = permute(w, [2,4,1,3]);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
w=reshape(w, [4, 4]);%ָ��Ϊ(sigma_{1}sigma_{1}',sigma_{2}sigma_{2}')
[U, S, V] = svd2(w); eta = size(S, 1);
U=U*sqrt(S); V=sqrt(S)*V;
U = reshape(U, [2, 2, eta]); 
V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 
U_mpo{1,1}=U;U_mpo{1,2}=V;
%%%%%%%%%

%spin up, impurity mu, bath mu and hopping evolution
%mix-canonical form at impurity site
for c1=1:L%bath site, first evolution, then swap site
    cs=L+1-c1;%position of bath
if cs==L%include the mu of site 1 and impurity, and hopping
    h=tup_matrix(cs)*kron(sm,sp)+tup_matrix(cs)'*kron(sp,sm)+mu_up(cs)*kron(occu,id)+mu_up_imp*kron(id,occu);
elseif cs<L%only include the mu of site c1, and hopping
    h=tup_matrix(cs)*kron(sm,sp)+tup_matrix(cs)'*kron(sp,sm)+mu_up(cs)*kron(occu,id);
end
    w=expm(-i*dt/2*h);
    w=reshape(w, [2, 2, 2, 2]); w = permute(w, [2,4,1,3]);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
if cs>1%swap
    w=contracttensors(swap,4,[2,4],w,4,[1,3]);%ָ��Ϊ(sigma_{1}'',sigma_{2}'',sigma_{1}',sigma_{2}')
    w=permute(w,[1,3,2,4]);%ָ��Ϊ(sigma_{1}'',sigma_{1}',sigma_{2}'',sigma_{2}'),Ҳ����(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
end
    w=reshape(w, [4, 4]);%ָ��Ϊ(sigma_{1}sigma_{1}',sigma_{2}sigma_{2}')
    [U, S, V] = svd2(w); eta = size(S, 1);
    U=U*sqrt(S); V=sqrt(S)*V;
    U = reshape(U, [2, 2, eta]); 
    V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 
    hop_up_first_mpo{c1,1}=U;hop_up_first_mpo{c1,2}=V;
end
%%%%%%%%%%%%

%spin up back
for c1=1:L%bath site, first evolution, then swap site
    cs=c1;%position of bath
if cs==L%include the mu of site 1 and impurity, and hopping
    h=tup_matrix(cs)*kron(sm,sp)+tup_matrix(cs)'*kron(sp,sm)+mu_up(cs)*kron(occu,id)+mu_up_imp*kron(id,occu);
elseif cs<L%only include the mu of site c1, and hopping
    h=tup_matrix(cs)*kron(sm,sp)+tup_matrix(cs)'*kron(sp,sm)+mu_up(cs)*kron(occu,id);
end
    w=expm(-i*dt/2*h);
    w=reshape(w, [2, 2, 2, 2]); w = permute(w, [2,4,1,3]);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
if cs>1%swap
    w=contracttensors(w,4,[2,4],swap,4,[1,3]);%ע�⣬��swap��evolve��ָ��Ϊ(sigma_{1}'',sigma_{2}'',sigma_{1}',sigma_{2}')
    w=permute(w,[1,3,2,4]);%ָ��Ϊ(sigma_{1}'',sigma_{1}',sigma_{2}'',sigma_{2}'),Ҳ����(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
end
    w=reshape(w, [4, 4]);%ָ��Ϊ(sigma_{1}sigma_{1}',sigma_{2}sigma_{2}')
    [U, S, V] = svd2(w); eta = size(S, 1);
    U=U*sqrt(S); V=sqrt(S)*V;
    U = reshape(U, [2, 2, eta]); 
    V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 
    hop_up_second_mpo{c1,1}=U;hop_up_second_mpo{c1,2}=V;
end
%%%%%%%%%%%


%spin down, impurity mu, bath mu and hopping evolution
%mix-canonical form at impurity site
for c1=1:L%bath site, first evolution, then swap site
    cs=c1;%position of bath
if cs==1%include the mu of site 1 and impurity, and hopping
    h=tdown_matrix(cs)'*kron(sm,sp)+tdown_matrix(cs)*kron(sp,sm)+mu_down(cs)*kron(id,occu)+mu_down_imp*kron(occu,id);
elseif cs>1%only include the mu of site c1, and hopping
    h=tdown_matrix(cs)'*kron(sm,sp)+tdown_matrix(cs)*kron(sp,sm)+mu_down(cs)*kron(id,occu);
end
    w=expm(-i*dt/2*h);
    w=reshape(w, [2, 2, 2, 2]); w = permute(w, [2,4,1,3]);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
if cs<L%swap
    w=contracttensors(swap,4,[2,4],w,4,[1,3]);%ָ��Ϊ(sigma_{1}'',sigma_{2}'',sigma_{1}',sigma_{2}')
    w=permute(w,[1,3,2,4]);%ָ��Ϊ(sigma_{1}'',sigma_{1}',sigma_{2}'',sigma_{2}'),Ҳ����(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
end
    w=reshape(w, [4, 4]);%ָ��Ϊ(sigma_{1}sigma_{1}',sigma_{2}sigma_{2}')
    [U, S, V] = svd2(w); eta = size(S, 1);
    U=U*sqrt(S); V=sqrt(S)*V;
    U = reshape(U, [2, 2, eta]); 
    V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 
    hop_down_first_mpo{c1,1}=U;hop_down_first_mpo{c1,2}=V;
end
%%%%%%%%%%

%spin down back
for c1=1:L%bath site, first evolution, then swap site
    cs=L+1-c1;%position of bath
if cs==1%include the mu of site 1 and impurity, and hopping
    h=tdown_matrix(cs)'*kron(sm,sp)+tdown_matrix(cs)*kron(sp,sm)+mu_down(cs)*kron(id,occu)+mu_down_imp*kron(occu,id);
elseif cs>1%only include the mu of site c1, and hopping
    h=tdown_matrix(cs)'*kron(sm,sp)+tdown_matrix(cs)*kron(sp,sm)+mu_down(cs)*kron(id,occu);
end
    w=expm(-i*dt/2*h);
    w=reshape(w, [2, 2, 2, 2]); w = permute(w, [2,4,1,3]);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
if cs<L%swap
    w=contracttensors(w,4,[2,4],swap,4,[1,3]);%ע�⣬��swap��evolve��ָ��Ϊ(sigma_{1}'',sigma_{2}'',sigma_{1}',sigma_{2}')
    w=permute(w,[1,3,2,4]);%ָ��Ϊ(sigma_{1}'',sigma_{1}',sigma_{2}'',sigma_{2}'),Ҳ����(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
end
    w=reshape(w, [4, 4]);%ָ��Ϊ(sigma_{1}sigma_{1}',sigma_{2}sigma_{2}')
    [U, S, V] = svd2(w); eta = size(S, 1);
    U=U*sqrt(S); V=sqrt(S)*V;
    U = reshape(U, [2, 2, eta]); 
    V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 
    hop_down_second_mpo{c1,1}=U;hop_down_second_mpo{c1,2}=V;
end
%%%%%%%%%%%





%time evolve

step=1;

TT(1)=abs(dt*(1-1));
G(1)=-i*overlap_1D(mps_quasiup0,mps_quasiup);


for time=2:round(Time/abs(dt))+1

%interaction evolution
%mix-canonical form at impurity site
mps_quasiup=left_norm_position(mps_quasiup,2*LL,LL+1);
mps_quasiup=right_norm_position(mps_quasiup,1,LL);
[mps_quasiup{1,LL},mps_quasiup{1,LL+1}]=twosite_precision(mps_quasiup{1,LL},mps_quasiup{1,LL+1},U_mpo{1,1},U_mpo{1,2},precision);
%%%%%%

%spin up, impurity mu, bath mu and hopping evolution
%mix-canonical form at impurity site
mps_quasiup=left_norm_position(mps_quasiup,LL+1,LL+1);
for c1=1:L%bath site, first evolution, then swap site
    cs=L+1-c1;%position of bath
    [mps_quasiup{1,cs},mps_quasiup{1,cs+1}]=twosite_precision(mps_quasiup{1,cs},mps_quasiup{1,cs+1},hop_up_first_mpo{c1,1},hop_up_first_mpo{c1,2},precision);
    mps_quasiup=left_norm_position(mps_quasiup,cs+1,cs+1);
end
%%%%%%

%spin up back
for c1=1:L%bath site, first evolution, then swap site
    cs=c1;%position of bath
    [mps_quasiup{1,cs},mps_quasiup{1,cs+1}]=twosite_precision(mps_quasiup{1,cs},mps_quasiup{1,cs+1},hop_up_second_mpo{c1,1},hop_up_second_mpo{c1,2},precision);
    mps_quasiup=right_norm_position(mps_quasiup,cs,cs);
end
%%%%%%

%spin down, impurity mu, bath mu and hopping evolution
%mix-canonical form at impurity site
mps_quasiup=right_norm_position(mps_quasiup,LL,LL);
for c1=1:L%bath site, first evolution, then swap site
    cs=c1;%position of bath
    [mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1}]=twosite_precision(mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1},hop_down_first_mpo{c1,1},hop_down_first_mpo{c1,2},precision);
    mps_quasiup=right_norm_position(mps_quasiup,LL+cs,LL+cs);
end
%%%%%

%spin down back
for c1=1:L%bath site, first evolution, then swap site
    cs=L+1-c1;%position of bath
    [mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1}]=twosite_precision(mps_quasiup{1,LL+cs},mps_quasiup{1,LL+cs+1},hop_down_second_mpo{c1,1},hop_down_second_mpo{c1,2},precision);
    mps_quasiup=left_norm_position(mps_quasiup,LL+cs+1,LL+cs+1);
end
%%%%

%interaction evolution
%mix-canonical form at impurity site
mps_quasiup=left_norm_position(mps_quasiup,LL+1,LL+1);
[mps_quasiup{1,LL},mps_quasiup{1,LL+1}]=twosite_precision(mps_quasiup{1,LL},mps_quasiup{1,LL+1},U_mpo{1,1},U_mpo{1,2},precision);



    TT(time)=abs(dt*(time-1));
    G(time)=-i*overlap_1D(mps_quasiup0,mps_quasiup)*exp(energy*i*abs(dt*(time-1)));
end


Green=cell(1,2);
Green{1,1}=TT;
Green{1,2}=G;
filenm=['G_Semielliptic_N' num2str(L) '_D_' num2str(D) '_2nd_trotter'];
save([filenm],'Green');
plot(TT,real(G),'r');hold on;
plot(TT,imag(G),'b');hold on;