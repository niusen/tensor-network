clc;clear;close all;
precision=10^-9;
sx=[0,1;1,0];sy=[0,-1i;1i,0];sz=[1,0;0,-1];id=eye(2);
occu=(eye(2)-sz)/2;

sp=(sx+i*sy)/2;
sm=(sx-i*sy)/2;
swap=zeros(2,2,2,2);%ָ��Ϊ(sigma_{1},sigma_{1}',sigma_{2},sigma_{2}')
swap(1,1,1,1)=1;
swap(1,2,2,1)=1;
swap(2,1,1,2)=1;
swap(2,2,2,2)=-1; 

swapo=reshape(swap,[4,4]);
[U, S, V] = svd2(swapo); eta = size(S, 1);
U=U*sqrt(S); V=sqrt(S)*V;
U = reshape(U, [2, 2, eta]); 
V = reshape(V, [eta, 2, 2]);V=permute(V,[2 3 1]); 


mps00=createrandommps(8, 4, 2);
mps0=mps00;
mps1=mps00;

op=cell(2,8);
for c1=1:2
for c2=1:8
op{c1,c2}=reshape(id,[1,1,2,2]);
end
end
%site2��7֮������
for c2=3:6
op{1,c2}=reshape(sz,[1,1,2,2]);
end
op{1,2}=reshape(sp,[1,1,2,2]);
op{1,7}=reshape(sm,[1,1,2,2]);
op{2,2}=reshape(sp,[1,1,2,2]);
op{2,3}=reshape(sm,[1,1,2,2]);

for cs=6:-1:3
mps0=right_norm_position(mps0,1,cs);
mps0=left_norm_position(mps0,8,cs+1);
[mps0{1,cs},mps0{1,cs+1}]=twosite_precision(mps0{1,cs},mps0{1,cs+1},U,V,precision);
end

mps0=mpo_mps(op(2,:),mps0);

for cs=3:6
mps0=right_norm_position(mps0,1,cs);
mps0=left_norm_position(mps0,8,cs+1);
[mps0{1,cs},mps0{1,cs+1}]=twosite_precision(mps0{1,cs},mps0{1,cs+1},U,V,precision);
end


mps1=mpo_mps(op(1,:),mps1);

overlap_1D(mps0,mps1)/sqrt(overlap_1D(mps1,mps1)*overlap_1D(mps0,mps0))






